import 'package:flutter/material.dart';
import 'activity_reminder_helper.dart';

/// Helper class for activity date and time operations
class ActivityDateTimeHelper {
  /// Check if activity date/time is in the future
  static bool isActivityInFuture(
    DateTime? selectedDate,
    TimeOfDay? selectedTime,
  ) {
    if (selectedDate == null || selectedTime == null) return false;

    final activityDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    return activityDateTime.isAfter(DateTime.now());
  }

  /// Create DateTime from date and time components
  static DateTime? createDateTime(DateTime? date, TimeOfDay? time) {
    if (date == null || time == null) return null;

    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }

  /// Check if a DateTime is in the past
  static bool isInPast(DateTime dateTime) {
    return dateTime.isBefore(DateTime.now());
  }

  /// Check if reminder date/time is valid (in the future)
  static bool isValidReminderDateTime(
    DateTime? reminderDate,
    TimeOfDay? reminderTime,
  ) {
    if (reminderDate == null || reminderTime == null) return false;

    final reminderDateTime = DateTime(
      reminderDate.year,
      reminderDate.month,
      reminderDate.day,
      reminderTime.hour,
      reminderTime.minute,
    );

    return reminderDateTime.isAfter(DateTime.now());
  }

  /// Check if activity and reminder dates need to be reset due to being in the past
  static ActivityDateTimeValidation validateActivityDateTime({
    required DateTime? selectedDate,
    required TimeOfDay? selectedTime,
    required DateTime? reminderDate,
    required TimeOfDay? reminderTime,
    required bool activityNotify,
  }) {
    bool shouldResetNotification = false;
    bool shouldResetReminder = false;

    // Check activity date/time - if activity is in past, disable all reminders
    if (selectedDate != null && selectedTime != null) {
      final activityDateTime = createDateTime(selectedDate, selectedTime)!;

      if (isInPast(activityDateTime)) {
        // Activity time has passed - disable reminders entirely
        shouldResetNotification = true;
        shouldResetReminder = true;
      }
    }

    // Check reminder date/time
    if (reminderDate != null && reminderTime != null) {
      // Check if reminder time has passed
      if (ActivityReminderHelper.hasReminderTimePassed(
        reminderDate: reminderDate,
        reminderTime: reminderTime,
      )) {
        shouldResetNotification = true;
        shouldResetReminder = true;
      } else {
        // Also check if reminder is after activity time (constraint validation)
        final isValidReminder = ActivityReminderHelper.isValidReminderDateTime(
          reminderDate: reminderDate,
          reminderTime: reminderTime,
          activityDate: selectedDate,
          activityTime: selectedTime,
        );

        if (!isValidReminder) {
          shouldResetNotification = true;
          shouldResetReminder = true;
        }
      }
    }

    return ActivityDateTimeValidation(
      shouldResetNotification: shouldResetNotification,
      shouldResetReminder: shouldResetReminder,
    );
  }

  /// Simplified validation when you have a full reminderDateTime
  static ActivityDateTimeValidation validateActivityDateTimeSimple({
    required DateTime? activityDateTime,
    required DateTime? reminderDateTime,
    required bool activityNotify,
  }) {
    bool shouldResetNotification = false;
    bool shouldResetReminder = false;

    // Check activity date/time
    if (activityDateTime != null &&
        isInPast(activityDateTime) &&
        activityNotify) {
      shouldResetNotification = true;
      shouldResetReminder = true;
    }

    // Check reminder date/time
    if (reminderDateTime != null &&
        (isInPast(reminderDateTime) ||
            (activityDateTime != null &&
                reminderDateTime.isAfter(activityDateTime)))) {
      shouldResetNotification = true;
      shouldResetReminder = true;
    }

    return ActivityDateTimeValidation(
      shouldResetNotification: shouldResetNotification,
      shouldResetReminder: shouldResetReminder,
    );
  }
}

/// Data class for date time validation results
class ActivityDateTimeValidation {
  final bool shouldResetNotification;
  final bool shouldResetReminder;

  const ActivityDateTimeValidation({
    required this.shouldResetNotification,
    required this.shouldResetReminder,
  });
}
