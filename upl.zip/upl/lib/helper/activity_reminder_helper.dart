import 'dart:async';
import 'package:flutter/material.dart';

/// Helper class for activity reminder operations
class ActivityReminderHelper {
  /// Show reminder date/time picker
  static Future<ReminderPickerResult?> showReminderPicker({
    required BuildContext context,
    required DateTime? currentReminderDate,
    required TimeOfDay? currentReminderTime,
    required DateTime? activityDate,
    required TimeOfDay? activityTime,
  }) async {
    final now = DateTime.now();

    // Calculate activity datetime for constraint validation
    DateTime? activityDateTime;
    if (activityDate != null && activityTime != null) {
      activityDateTime = DateTime(
        activityDate.year,
        activityDate.month,
        activityDate.day,
        activityTime.hour,
        activityTime.minute,
      );
    }

    // Show date picker
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: currentReminderDate ?? now,
      firstDate: now,
      lastDate: activityDate ?? now.add(const Duration(days: 365)),
    );

    if (pickedDate != null && context.mounted) {
      // Show time picker
      TimeOfDay? pickedTime = await showTimePicker(
        context: context,
        initialTime: currentReminderTime ?? TimeOfDay.now(),
      );

      if (pickedTime != null) {
        final reminderDateTime = DateTime(
          pickedDate.year,
          pickedDate.month,
          pickedDate.day,
          pickedTime.hour,
          pickedTime.minute,
        );

        // Validate reminder constraints:
        // 1. Must be after current time
        // 2. Must be before activity date/time
        final isAfterNow = reminderDateTime.isAfter(DateTime.now());
        final isBeforeActivity =
            activityDateTime == null ||
            reminderDateTime.isBefore(activityDateTime);

        if (isAfterNow && isBeforeActivity) {
          return ReminderPickerResult(
            date: pickedDate,
            time: pickedTime,
            isValid: true,
          );
        } else {
          // Show appropriate error message
          _showReminderError(
            context,
            isAfterNow,
            isBeforeActivity,
            activityDateTime,
          );
        }
      }
    }

    return null;
  }

  /// Create a timer for checking activity date/time periodically
  static Timer createDateTimeCheckTimer({
    required VoidCallback onCheck,
    Duration interval = const Duration(seconds: 1),
  }) {
    return Timer.periodic(interval, (_) => onCheck());
  }

  /// Animate bell icon
  static Future<void> animateBell(AnimationController controller) async {
    await controller.forward();
    await controller.reverse();
  }

  /// Check if reminder picker should be enabled
  static bool shouldEnableReminderPicker({
    required DateTime? selectedDate,
    required TimeOfDay? selectedTime,
  }) {
    if (selectedDate == null || selectedTime == null) return false;

    final activityDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    return activityDateTime.isAfter(DateTime.now());
  }

  /// Validate if reminder date/time is within constraints
  static bool isValidReminderDateTime({
    required DateTime reminderDate,
    required TimeOfDay reminderTime,
    required DateTime? activityDate,
    required TimeOfDay? activityTime,
  }) {
    final reminderDateTime = DateTime(
      reminderDate.year,
      reminderDate.month,
      reminderDate.day,
      reminderTime.hour,
      reminderTime.minute,
    );

    final now = DateTime.now();

    // Must be after current time
    if (!reminderDateTime.isAfter(now)) return false;

    // Must be before activity date/time if available
    if (activityDate != null && activityTime != null) {
      final activityDateTime = DateTime(
        activityDate.year,
        activityDate.month,
        activityDate.day,
        activityTime.hour,
        activityTime.minute,
      );

      if (!reminderDateTime.isBefore(activityDateTime)) return false;
    }

    return true;
  }

  /// Show error dialog for invalid reminder time
  static void _showReminderError(
    BuildContext context,
    bool isAfterNow,
    bool isBeforeActivity,
    DateTime? activityDateTime,
  ) {
    String title;
    String message;

    if (!isAfterNow) {
      title = 'Invalid Reminder Time';
      message =
          'The reminder time must be in the future. Please select a time that hasn\'t passed yet.';
    } else if (!isBeforeActivity && activityDateTime != null) {
      final activityTimeStr =
          '${activityDateTime.day}/${activityDateTime.month}/${activityDateTime.year} at ${activityDateTime.hour.toString().padLeft(2, '0')}:${activityDateTime.minute.toString().padLeft(2, '0')}';
      title = 'Invalid Reminder Time';
      message =
          'The reminder must be set before the activity time.\n\nActivity is scheduled for: $activityTimeStr';
    } else {
      title = 'Invalid Reminder';
      message = 'Please select a valid reminder time.';
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(
                Icons.error_outline,
                color: Theme.of(context).colorScheme.error,
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  title,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          content: Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'OK',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          backgroundColor: Theme.of(context).colorScheme.surface,
          elevation: 3,
          shadowColor: Theme.of(
            context,
          ).colorScheme.shadow.withValues(alpha: 0.15),
        );
      },
    );
  }

  /// Show error dialog when activity is not in future
  static void _showActivityNotInFutureError(
    BuildContext context,
    DateTime? selectedDate,
    TimeOfDay? selectedTime,
  ) {
    String message = 'Cannot set reminder for past activities.';

    if (selectedDate != null && selectedTime != null) {
      final activityDateTime = DateTime(
        selectedDate.year,
        selectedDate.month,
        selectedDate.day,
        selectedTime.hour,
        selectedTime.minute,
      );
      final activityTimeStr =
          '${activityDateTime.day}/${activityDateTime.month}/${activityDateTime.year} at ${activityDateTime.hour.toString().padLeft(2, '0')}:${activityDateTime.minute.toString().padLeft(2, '0')}';
      message =
          'Cannot set reminder for past activities.\n\nThe activity is scheduled for: $activityTimeStr\n\nPlease change the activity time to a future date and time to enable reminders.';
    }

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Row(
            children: [
              Icon(
                Icons.schedule_outlined,
                color: Theme.of(context).colorScheme.error,
                size: 24,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Cannot Set Reminder',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
          content: Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              height: 1.4,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'OK',
                style: TextStyle(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          backgroundColor: Theme.of(context).colorScheme.surface,
          elevation: 3,
          shadowColor: Theme.of(
            context,
          ).colorScheme.shadow.withValues(alpha: 0.15),
        );
      },
    );
  }

  /// Check if a specific reminder DateTime has passed
  static bool hasReminderTimePassed({
    required DateTime? reminderDate,
    required TimeOfDay? reminderTime,
  }) {
    if (reminderDate == null || reminderTime == null) return false;

    final reminderDateTime = DateTime(
      reminderDate.year,
      reminderDate.month,
      reminderDate.day,
      reminderTime.hour,
      reminderTime.minute,
    );

    return reminderDateTime.isBefore(DateTime.now());
  }

  /// Check if a specific activity DateTime has passed
  static bool hasActivityTimePassed({
    required DateTime? activityDate,
    required TimeOfDay? activityTime,
  }) {
    if (activityDate == null || activityTime == null) return false;

    final activityDateTime = DateTime(
      activityDate.year,
      activityDate.month,
      activityDate.day,
      activityTime.hour,
      activityTime.minute,
    );

    return activityDateTime.isBefore(DateTime.now());
  }

  /// Handle reminder toggle - either turn off or show picker
  static Future<ReminderToggleResult> handleReminderToggle({
    required BuildContext context,
    required bool currentlyActive,
    required DateTime? currentReminderDate,
    required TimeOfDay? currentReminderTime,
    required DateTime? activityDate,
    required TimeOfDay? activityTime,
    required DateTime? selectedDate,
    required TimeOfDay? selectedTime,
  }) async {
    // If already active, turn it off
    if (currentlyActive) {
      return const ReminderToggleResult(
        shouldActivate: false,
        reminderDate: null,
        reminderTime: null,
      );
    }

    // If not active, check if activity is in future and show picker
    if (!shouldEnableReminderPicker(
      selectedDate: selectedDate,
      selectedTime: selectedTime,
    )) {
      _showActivityNotInFutureError(context, selectedDate, selectedTime);
      return const ReminderToggleResult(
        shouldActivate: false,
        reminderDate: null,
        reminderTime: null,
      );
    }

    // Show picker for new reminder
    final result = await showReminderPicker(
      context: context,
      currentReminderDate: currentReminderDate,
      currentReminderTime: currentReminderTime,
      activityDate: activityDate,
      activityTime: activityTime,
    );

    if (result != null) {
      return ReminderToggleResult(
        shouldActivate: true,
        reminderDate: result.date,
        reminderTime: result.time,
      );
    }

    return const ReminderToggleResult(
      shouldActivate: false,
      reminderDate: null,
      reminderTime: null,
    );
  }
}

/// Data class for reminder picker results
class ReminderPickerResult {
  final DateTime date;
  final TimeOfDay time;
  final bool isValid;

  const ReminderPickerResult({
    required this.date,
    required this.time,
    required this.isValid,
  });

  /// Convert to DateTime
  DateTime toDateTime() {
    return DateTime(date.year, date.month, date.day, time.hour, time.minute);
  }
}

/// Data class for reminder toggle results
class ReminderToggleResult {
  final bool shouldActivate;
  final DateTime? reminderDate;
  final TimeOfDay? reminderTime;

  const ReminderToggleResult({
    required this.shouldActivate,
    required this.reminderDate,
    required this.reminderTime,
  });
}
