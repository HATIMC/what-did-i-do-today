import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import '../model/activity.dart';
import '../model/enum/mood.dart';
import '../model/checklist.dart';
import '../model/activity_media.dart';
import '../model/profile.dart';
import '../features/models/activity_form_models.dart';
import '../service/activity_manager.dart';

/// Helper class for activity creation operations
class ActivityCreationHelper {
  /// Create an Activity from form data
  static Activity createActivity({
    required String title,
    required String description,
    required String location,
    required String category,
    required DateTime selectedDate,
    required TimeOfDay selectedTime,
    required int durationHours,
    required int durationMinutes,
    required List<String> tags,
    required bool isImportant,
    required bool isCompleted,
    required bool activityNotify,
    required DateTime? reminderDate,
    required TimeOfDay? reminderTime,
    required List<ChecklistItem> checklist,
    required List<ActivityMedia> attachments,
    required Profile selectedProfile,
    required ActivityMood mood,
    String? existingActivityId,
  }) {
    // Create DateTime from selected date and time
    final selectedDateTime = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
      selectedTime.hour,
      selectedTime.minute,
    );

    // Create Duration from hours and minutes
    final duration = Duration(hours: durationHours, minutes: durationMinutes);

    // Create reminderDateTime from reminderDate and reminderTime
    DateTime? reminderDateTime;
    if (reminderDate != null && reminderTime != null) {
      reminderDateTime = DateTime(
        reminderDate.year,
        reminderDate.month,
        reminderDate.day,
        reminderTime.hour,
        reminderTime.minute,
      );
    }

    return Activity(
      activityId:
          existingActivityId ??
          const Uuid().v4(), // Use existing ID or generate new one
      activityTitle: title.trim(),
      activityContent: description.trim(),
      activityMedia: attachments,
      activityCategory: category,
      activityMood: mood,
      activityDatetime: selectedDateTime,
      activityModifiedDate: DateTime.now(),
      activityStarred: isImportant,
      activityProfileId: selectedProfile.profileId,
      activityDone: isCompleted,
      activityNotify: activityNotify,
      checklist: checklist,
      location: location.trim().isEmpty ? null : location.trim(),
      tags: tags,
      activityDuration: duration.inMinutes > 0 ? duration : null,
      reminderDateTime: reminderDateTime,
    );
  }

  /// Save activity using ActivityManager
  static Future<void> saveActivity({
    required BuildContext context,
    required Activity activity,
    required ActivityFormData formData,
    bool isEdit = false,
  }) async {
    final activityManager = Provider.of<ActivityManager>(
      context,
      listen: false,
    );

    if (isEdit) {
      await activityManager.updateActivity(activity);
    } else {
      await activityManager.addActivity(activity);
    }

    // Show success message
    ActivityFormUtils.showSuccessMessage(context, formData);
  }

  /// Validate form data and return validation message if invalid
  static String? validateFormData({
    required String title,
    required Profile? selectedProfile,
  }) {
    List<String> missing = [];

    if (title.trim().isEmpty) {
      missing.add('Activity title');
    }
    if (selectedProfile == null) {
      missing.add('Select a profile');
    }

    if (missing.isEmpty) return null;

    String message = 'Please complete the following:';
    message += '\n• ${missing.join('\n• ')}';
    return message;
  }

  /// Handle complete save operation with validation and error handling
  static Future<bool> handleSaveActivity({
    required BuildContext context,
    required ActivityFormData formData,
    String? existingActivityId,
  }) async {
    // Validate form data
    final validationMessage = validateFormData(
      title: formData.title,
      selectedProfile: formData.selectedProfile,
    );

    if (validationMessage != null) {
      ActivityFormUtils.showValidationMessage(context, validationMessage);
      return false;
    }

    try {
      final isEdit = existingActivityId != null;

      // Create activity from form data
      final activity = createActivity(
        title: formData.title,
        description: formData.description,
        location: formData.location,
        category: formData.category,
        selectedDate: formData.date ?? DateTime.now(),
        selectedTime: formData.time ?? TimeOfDay.now(),
        durationHours: formData.durationHours,
        durationMinutes: formData.durationMinutes,
        tags: formData.tags,
        isImportant: formData.isImportant,
        isCompleted: formData.isCompleted,
        activityNotify: formData.activityNotify,
        reminderDate: formData.reminderDate,
        reminderTime: formData.reminderTime,
        checklist: formData.checklist,
        attachments: formData.attachments,
        selectedProfile: formData.selectedProfile!,
        mood: formData.mood,
        existingActivityId: existingActivityId,
      );

      // Save the activity
      await saveActivity(
        context: context,
        activity: activity,
        formData: formData,
        isEdit: isEdit,
      );

      return true;
    } catch (e) {
      // Handle any errors during saving
      ActivityFormUtils.showValidationMessage(
        context,
        'Error saving activity: $e',
      );
      return false;
    }
  }
}
