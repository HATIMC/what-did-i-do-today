import 'dart:async';
import 'dart:math';

class GreetingAnimationController {
  static const Duration _typingDelay = Duration(milliseconds: 50);
  static const Duration _mistakeDelay = Duration(milliseconds: 250);
  static const Duration _correctionDelay = Duration(milliseconds: 150);

  String _animatedText = '';
  bool _isAnimating = false;
  bool _showCursor = true;
  Timer? _cursorTimer;

  String get animatedText => _animatedText;
  bool get isAnimating => _isAnimating;
  bool get showCursor => _showCursor;

  void dispose() {
    _cursorTimer?.cancel();
  }

  static String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour <= 8) {
      return 'Good Morning!';
    } else if (hour > 8 && hour < 12) {
      return 'Good Day!';
    } else if (hour >= 12 && hour <= 16) {
      return 'Good Afternoon!';
    } else {
      return 'Good Evening!';
    }
  }

  static String _getRandomChar({String exclude = ''}) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.,!? ';
    final random = Random();
    String char;
    do {
      char = chars[random.nextInt(chars.length)];
    } while (char == exclude);
    return char;
  }

  void startGreetingAnimation({
    required String userName,
    required bool mounted,
    required Function() onUpdate,
  }) {
    // Only run if not currently animating
    if (_isAnimating || !mounted) return;

    final String fullText = '${getGreeting()} I am $userName';

    // Cancel any ongoing animation and reset
    _cursorTimer?.cancel();
    _animatedText = '';
    _showCursor = false; // Start with cursor hidden

    _isAnimating = true;
    _showCursor = true;
    onUpdate();

    int currentIndex = 0;
    final random = Random();

    // Start the cursor blinking immediately
    _cursorTimer = Timer.periodic(const Duration(milliseconds: 500), (timer) {
      if (!mounted || !_isAnimating) {
        timer.cancel();
        _showCursor = false; // Hide cursor when animation stops
        onUpdate();
        return;
      }
      _showCursor = !_showCursor;
      onUpdate();
    });

    void typeNext() async {
      if (!mounted) {
        _isAnimating = false; // Mark as not animating if widget is disposed
        _cursorTimer?.cancel();
        return;
      }

      if (currentIndex >= fullText.length) {
        _isAnimating = false;
        _showCursor = false;
        _cursorTimer
            ?.cancel(); // Ensure cursor timer is cancelled when typing is complete
        onUpdate();
        return;
      }

      bool makeMistake =
          currentIndex > 2 && random.nextBool() && random.nextInt(5) == 0;

      if (makeMistake) {
        String wrongChar = _getRandomChar(exclude: fullText[currentIndex]);
        _animatedText += wrongChar;
        onUpdate();

        await Future.delayed(_mistakeDelay);
        if (!mounted) return;

        _animatedText = _animatedText.substring(0, _animatedText.length - 1);
        onUpdate();

        await Future.delayed(_correctionDelay);
        if (!mounted) return;
      }

      _animatedText += fullText[currentIndex];
      currentIndex++;
      onUpdate();

      await Future.delayed(_typingDelay);
      if (!mounted) return;
      typeNext();
    }

    typeNext();
  }
}
