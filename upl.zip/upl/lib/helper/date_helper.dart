class DateHelper {
  static String getMonthName(int month) {
    switch (month) {
      case 1:
        return 'January';
      case 2:
        return 'February';
      case 3:
        return 'March';
      case 4:
        return 'April';
      case 5:
        return 'May';
      case 6:
        return 'June';
      case 7:
        return 'July';
      case 8:
        return 'August';
      case 9:
        return 'September';
      case 10:
        return 'October';
      case 11:
        return 'November';
      case 12:
        return 'December';
      default:
        return '';
    }
  }

  static String getActivityTitle(DateTime selectedDate) {
    final DateTime now = DateTime.now();
    final DateTime today = DateTime(now.year, now.month, now.day);
    final DateTime selected = DateTime(
      selectedDate.year,
      selectedDate.month,
      selectedDate.day,
    );
    final int diffDays = selected.difference(today).inDays;

    final List<String> weekdayNames = [
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday',
      'Sunday',
    ];
    final String selectedWeekdayName = weekdayNames[selected.weekday - 1];

    if (diffDays == 0) {
      return 'What did I do today?';
    } else if (diffDays == -1) {
      return 'What did I do yesterday?';
    } else if (diffDays == 1) {
      return 'What will I do tomorrow?';
    }

    if (selected.isBefore(today)) {
      if (diffDays >= -7 && diffDays <= 2) {
        return 'What did I do last $selectedWeekdayName?';
      } else {
        if (selected.year == today.year - 1) {
          return 'What did I do last year?';
        }
        return 'What did I do that day?';
      }
    } else {
      if (diffDays >= 2 && diffDays <= 7) {
        return 'What will I do next $selectedWeekdayName?';
      } else {
        if (selected.year == today.year + 1) {
          return 'What will I do next year?';
        }
        return 'What will I do that day?';
      }
    }
  }

  static String formatTime(DateTime dateTime) {
    final hour = dateTime.hour;
    final minute = dateTime.minute;
    final period = hour >= 12 ? 'PM' : 'AM';
    final displayHour = hour > 12
        ? hour - 12
        : hour == 0
        ? 12
        : hour;
    final minuteStr = minute.toString().padLeft(2, '0');
    return '$displayHour:$minuteStr $period';
  }

  static String formatDate(DateTime dateTime) {
    final month = getMonthName(dateTime.month);
    return '$month ${dateTime.day}, ${dateTime.year}';
  }
}
