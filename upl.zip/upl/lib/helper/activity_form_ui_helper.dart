import 'package:flutter/material.dart';

/// Helper class for activity form UI operations
class ActivityFormUIHelper {
  /// Build the drag handle widget for bottom sheets
  static Widget buildDragHandle(BuildContext context) {
    return Center(
      child: Container(
        width: 40,
        height: 4,
        margin: const EdgeInsets.only(bottom: 16.0),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  /// Build animated bell icon with rotation animation
  static Widget buildAnimatedBellIcon({
    required AnimationController animationController,
    required VoidCallback onPressed,
    required bool isActive,
    required BuildContext context,
  }) {
    return AnimatedBuilder(
      animation: animationController,
      builder: (context, child) {
        return Transform.rotate(
          angle: animationController.value * 0.3,
          child: IconButton(
            onPressed: onPressed,
            icon: Icon(
              isActive
                  ? Icons.notifications_active
                  : Icons.notifications_outlined,
              color: isActive
                  ? Colors.orange
                  : Theme.of(context).colorScheme.primary,
              size: 20,
            ),
            tooltip: 'Set Reminder',
            style: IconButton.styleFrom(
              backgroundColor: isActive
                  ? Colors.orange.withOpacity(0.1)
                  : Theme.of(
                      context,
                    ).colorScheme.surfaceVariant.withOpacity(0.3),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Build expandable details button
  static Widget buildExpandableDetailsButton({
    required BuildContext context,
    required VoidCallback onPressed,
  }) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        key: const ValueKey('addTimeBtn'),
        icon: Icon(
          Icons.expand_more_outlined,
          color: Theme.of(context).colorScheme.primary,
          size: 20,
        ),
        label: const Text('Add more details'),
        style: OutlinedButton.styleFrom(
          foregroundColor: Theme.of(context).iconTheme.color,
          textStyle: Theme.of(context).textTheme.bodyLarge,
          side: BorderSide(color: Theme.of(context).colorScheme.outline),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16),
        ),
        onPressed: onPressed,
      ),
    );
  }

  /// Build animated switcher for expandable content
  static Widget buildAnimatedSwitcher({
    required bool showDetails,
    required Widget collapsedWidget,
    required Widget expandedWidget,
  }) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      switchInCurve: Curves.easeOutCubic,
      switchOutCurve: Curves.easeInCubic,
      child: showDetails ? expandedWidget : collapsedWidget,
    );
  }

  /// Calculate snap sizes for DraggableScrollableSheet
  static List<double> getSnapSizes(bool showExpandedMode) {
    return showExpandedMode ? [0.5, 0.9] : [0.5, 0.7];
  }

  /// Get initial child size for DraggableScrollableSheet
  static double getInitialChildSize(bool showExpandedMode) {
    return showExpandedMode ? 0.9 : 0.7;
  }
}
