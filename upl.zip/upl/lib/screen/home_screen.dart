import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hello_world/features/settings_bottom_sheet.dart';
import 'package:hello_world/features/about_bottom_sheet.dart';
import 'package:hello_world/features/add_activity_bottom_sheet.dart';
import 'package:hello_world/features/profile_selector_bottom_sheet.dart';
import 'package:hello_world/features/notifications_bottom_sheet.dart';
import 'package:hello_world/service/profile_manager.dart';
import 'package:hello_world/service/theme_manager.dart';
import 'package:hello_world/service/activity_manager.dart';
import 'package:hello_world/model/activity.dart';
import 'package:provider/provider.dart';

// Import the new components
import '../helper/greeting_animation_helper.dart';
import '../helper/profile_manager_helper.dart';
import 'widgets/home_screen_app_bar.dart';
import 'widgets/calendar_section.dart';
import 'widgets/activities_list.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;
  bool _isCalendarVisible = false;
  late AnimationController _animationController;
  late GreetingAnimationController _greetingController;

  // We'll use this to track if the initial animation has run.
  bool _hasInitialGreetingAnimated = false;

  // Add drag tracking state
  bool _isDragActive = false;
  bool _isOverDeleteZone = false;

  // Timer for cleaning up expired reminders
  Timer? _reminderCleanupTimer;

  // Drag tracking variables
  Offset? _pointerDownPos;
  Offset? _pointerLastPos;
  DateTime? _pointerDownAt;
  bool _verticalBiasDetected = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    );

    _greetingController = GreetingAnimationController();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeApp();
    });

    // Start timer to cleanup expired reminders every 5 seconds
    _startReminderCleanupTimer();
  }

  void _initializeApp() {
    final themeManager = Provider.of<ThemeManager>(context, listen: false);
    final profileManager = Provider.of<ProfileManager>(context, listen: false);

    // Check if preferences are loaded AND profile manager has finished loading
    if (themeManager.preferencesLoaded &&
        profileManager.isLoaded &&
        !_hasInitialGreetingAnimated) {
      _handleInitialSetup(profileManager);
    } else if (!themeManager.preferencesLoaded || !profileManager.isLoaded) {
      // Listen to both managers for changes
      themeManager.addListener(_startInitialGreetingOnPreferencesLoad);
      profileManager.addListener(_startInitialGreetingOnPreferencesLoad);
    }

    // Add listener for profile changes to re-animate greeting
    profileManager.addListener(_onProfileChanged);
  }

  void _handleInitialSetup(ProfileManager profileManager) {
    // Check if no profiles exist - force profile creation
    if (ProfileManagerHelper.shouldShowProfileSelector(profileManager)) {
      _showProfileSelectorBottomSheet();
    } else if (profileManager.currentProfile != null) {
      // Has profiles and current profile is set
      _startGreetingAnimation();
      _hasInitialGreetingAnimated = true;
    }
  }

  void _startInitialGreetingOnPreferencesLoad() {
    if (!mounted) return;

    final themeManager = Provider.of<ThemeManager>(context, listen: false);
    final profileManager = Provider.of<ProfileManager>(context, listen: false);

    if (themeManager.preferencesLoaded &&
        profileManager.isLoaded &&
        !_hasInitialGreetingAnimated) {
      _handleInitialSetup(profileManager);

      // Remove both listeners
      themeManager.removeListener(_startInitialGreetingOnPreferencesLoad);
      profileManager.removeListener(_startInitialGreetingOnPreferencesLoad);
    }
  }

  void _onProfileChanged() {
    if (!mounted) return;

    // Only re-animate if the initial greeting has already been shown
    if (_hasInitialGreetingAnimated) {
      _startGreetingAnimation();
    }
  }

  void _startGreetingAnimation() {
    final profile = Provider.of<ProfileManager>(
      context,
      listen: false,
    ).currentProfile;
    final String userName = profile?.profileName ?? 'Unknown';

    _greetingController.startGreetingAnimation(
      userName: userName,
      mounted: mounted,
      onUpdate: () {
        if (mounted) setState(() {});
      },
    );
  }

  void _startReminderCleanupTimer() {
    _reminderCleanupTimer = Timer.periodic(const Duration(seconds: 5), (
      timer,
    ) async {
      if (!mounted) return;

      final activityManager = Provider.of<ActivityManager>(
        context,
        listen: false,
      );
      await _cleanupExpiredReminders(activityManager);
    });
  }

  Future<void> _cleanupExpiredReminders(ActivityManager activityManager) async {
    final now = DateTime.now();
    final allActivities = activityManager.activities;

    for (final activity in allActivities) {
      // Check if activity has notification enabled with a past reminder date
      if (activity.activityNotify &&
          activity.reminderDateTime != null &&
          activity.reminderDateTime!.isBefore(now)) {
        // Create updated activity with notification disabled
        final updatedActivity = activity.copyWith(
          activityNotify: false,
          reminderDateTime: null,
        );

        // Update the activity in the manager
        await activityManager.updateActivity(updatedActivity);
      }
    }
  }

  // Show profile selector bottom sheet
  Future<void> _showProfileSelectorBottomSheet({
    bool dismissible = false,
  }) async {
    await ProfileManagerHelper.showProfileSelectorBottomSheet(
      context,
      dismissible: dismissible,
      onCreateProfile: _showMandatoryProfileBottomSheet,
    );

    // After profile selection, start greeting animation
    if (mounted) {
      _startGreetingAnimation();
      _hasInitialGreetingAnimated = true;
    }
  }

  // Show mandatory profile creation bottom sheet (non-dismissible)
  Future<void> _showMandatoryProfileBottomSheet() async {
    await ProfileManagerHelper.showMandatoryProfileBottomSheet(context);

    // After profile creation, start greeting animation
    if (mounted) {
      _startGreetingAnimation();
      _hasInitialGreetingAnimated = true;
    }
  }

  @override
  void dispose() {
    _greetingController.dispose();
    _reminderCleanupTimer?.cancel();
    WidgetsBinding.instance.removeObserver(this);

    // Remove listeners from both managers
    if (mounted) {
      final themeManager = Provider.of<ThemeManager>(context, listen: false);
      final profileManager = Provider.of<ProfileManager>(
        context,
        listen: false,
      );

      themeManager.removeListener(_startInitialGreetingOnPreferencesLoad);
      profileManager.removeListener(_startInitialGreetingOnPreferencesLoad);
      profileManager.removeListener(_onProfileChanged);
    }

    _animationController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      // App is returning to the foreground (e.g., from minimized, or after a call)
      _startGreetingAnimation();
    } else if (state == AppLifecycleState.paused) {
      // App is going to background
      debugPrint('🔔 App paused');
    }
  }

  /// Helper method to check if two dates are the same day
  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  /// Handles deletion of an activity through drag-and-drop
  Future<void> _deleteActivity(Activity activity) async {
    final activityManager = Provider.of<ActivityManager>(
      context,
      listen: false,
    );

    // Show confirmation dialog
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Activity'),
        content: Text(
          'Are you sure you want to delete "${activity.activityTitle}"? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await activityManager.deleteActivity(activity.activityId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('${activity.activityTitle} deleted'),
            duration: const Duration(seconds: 2),
          ),
        );
      }
    }
  }

  /// Builds the delete zone that appears at the bottom during drag operations
  Widget _buildDeleteZone() {
    return Positioned(
      left: 16,
      right: 16,
      bottom:
          MediaQuery.of(context).size.height * 0.1, // 10% from bottom of screen
      child: DragTarget<Activity>(
        onWillAccept: (activity) {
          setState(() => _isOverDeleteZone = true);
          return activity != null;
        },
        onLeave: (activity) {
          setState(() => _isOverDeleteZone = false);
        },
        onAccept: (activity) async {
          setState(() {
            _isDragActive = false;
            _isOverDeleteZone = false;
          });
          await _deleteActivity(activity);
        },
        builder: (context, candidateData, rejectedData) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            height: 80,
            decoration: BoxDecoration(
              color: _isOverDeleteZone
                  ? Theme.of(context).colorScheme.error
                  : Theme.of(context).colorScheme.error.withOpacity(0.7),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Theme.of(context).colorScheme.error,
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: Theme.of(context).colorScheme.error.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.delete_outline,
                  size: 32,
                  color: Theme.of(context).colorScheme.onError,
                ),
                const SizedBox(width: 12),
                Text(
                  'Drop to Delete',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onError,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // Function to show a generic bottom sheet
  Future<void> _showBottomSheet(BuildContext context, Widget content) async {
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return content;
      },
      isScrollControlled: true,
      enableDrag: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
      ),
    );

    // This code will execute when the bottom sheet is dismissed
    if (mounted) {
      _startGreetingAnimation();
    }
  }

  // Function to show the about bottom sheet with proper slide-to-close
  Future<void> _showAboutBottomSheet(BuildContext context) async {
    await showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return const AboutBottomSheet();
      },
      isScrollControlled: false,
      enableDrag: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
      ),
    );

    // This code will execute when the bottom sheet is dismissed
    if (mounted) {
      _startGreetingAnimation();
    }
  }

  @override
  Widget build(BuildContext context) {
    // Determine the comparison day for the AppBar title
    final DateTime comparisonDay = _selectedDay ?? _focusedDay;

    return PopScope(
      canPop: false, // Never allow normal pop behavior
      onPopInvoked: (didPop) async {
        if (didPop) {
          return;
        }

        // If calendar is visible, close it first
        if (_isCalendarVisible) {
          setState(() {
            _isCalendarVisible = false;
          });
          return;
        }

        // Instead of killing the app, move it to background
        // This keeps notifications running
        try {
          await SystemNavigator.pop();
        } catch (e) {
          // If SystemNavigator.pop() fails, try moving to background
          SystemChannels.platform.invokeMethod('SystemNavigator.pop');
        }
      },
      child: Scaffold(
        backgroundColor: Theme.of(context).colorScheme.surface,
        appBar: HomeScreenAppBar(
          animationController: _greetingController,
          selectedDay: comparisonDay,
          onProfileTap: () {
            _showBottomSheet(context, const ProfileSelectorBottomSheet());
          },
          onSettingsTap: () {
            _showBottomSheet(context, const SettingsBottomSheet());
          },
          onAboutTap: () {
            _showAboutBottomSheet(context);
          },
          onNotificationsTap: () {
            _showBottomSheet(context, const NotificationsBottomSheet());
          },
        ),
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Theme.of(context).colorScheme.surface,
                Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.1),
              ],
            ),
          ),
          child: Stack(
            children: [
              // Main content with improved layout
              SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 100), // Space for FAB
                child: Column(
                  children: [
                    // Calendar section with enhanced spacing
                    Container(
                      margin: const EdgeInsets.only(top: 8),
                      child: CalendarSection(
                        focusedDay: _focusedDay,
                        selectedDay: _selectedDay,
                        isCalendarVisible: _isCalendarVisible,
                        activities: Provider.of<ActivityManager>(context, listen: false).activities,
                        onDaySelected: (selectedDay, focusedDay) {
                          setState(() {
                            _selectedDay = selectedDay;
                            _focusedDay = focusedDay;
                          });
                        },
                        onPageChanged: (focusedDay) {
                          setState(() {
                            _focusedDay = focusedDay;
                          });
                        },
                        onPreviousDay: () {
                          setState(() {
                            _focusedDay = _focusedDay.subtract(
                              const Duration(days: 1),
                            );
                            _selectedDay = _focusedDay;
                          });
                        },
                        onToday: () {
                          final today = DateTime.now();

                          // Always navigate to today if we're not viewing today's month/year
                          // or if today is not selected
                          if (!_isSameDay(_focusedDay, today) ||
                              (_selectedDay != null &&
                                  !_isSameDay(_selectedDay!, today)) ||
                              _selectedDay == null) {
                            setState(() {
                              _focusedDay = today;
                              _selectedDay = today;
                            });
                          }
                        },
                        onNextDay: () {
                          setState(() {
                            _focusedDay = _focusedDay.add(const Duration(days: 1));
                            _selectedDay = _focusedDay;
                          });
                        },
                        onToggleCalendar: () {
                          setState(() {
                            _isCalendarVisible = !_isCalendarVisible;
                          });
                        },
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Activities section with swipe gesture detection (non-intrusive)
                    Listener(
                      onPointerDown: (event) {
                        _pointerDownPos = event.position;
                        _pointerLastPos = event.position;
                        _pointerDownAt = DateTime.now();
                        _verticalBiasDetected = false;
                      },
                      onPointerMove: (event) {
                        if (_pointerDownPos == null) return;
                        _pointerLastPos = event.position;
                        final dx = (_pointerLastPos!.dx - _pointerDownPos!.dx).abs();
                        final dy = (_pointerLastPos!.dy - _pointerDownPos!.dy).abs();
                        // If vertical movement dominates early, bias toward vertical scrolling
                        if (dy > dx + 8) {
                          _verticalBiasDetected = true;
                        }
                      },
                      onPointerUp: (event) {
                        if (_pointerDownPos == null || _pointerLastPos == null) {
                          _pointerDownPos = null;
                          _pointerLastPos = null;
                          _pointerDownAt = null;
                          _verticalBiasDetected = false;
                          return;
                        }
                        if (_isDragActive) {
                          // Ignore swipe navigation during drag-to-delete interactions
                          _pointerDownPos = null;
                          _pointerLastPos = null;
                          _pointerDownAt = null;
                          _verticalBiasDetected = false;
                          return;
                        }
                        final totalDx = _pointerLastPos!.dx - _pointerDownPos!.dx;
                        final totalDy = _pointerLastPos!.dy - _pointerDownPos!.dy;
                        final absDx = totalDx.abs();
                        final absDy = totalDy.abs();
                        final elapsedMs = _pointerDownAt != null
                            ? DateTime.now().difference(_pointerDownAt!).inMilliseconds
                            : null;

                        // Only consider as horizontal swipe if:
                        // - Clear horizontal intent (angle within ~33 degrees): absDx > 1.5 * absDy
                        // - Sufficient distance: absDx >= 80
                        // - Not strongly vertical-biased during movement
                        // - Reasonable speed if time available: absDx / elapsedMs > 0.3 px/ms (~300 px/s)
                        final bool clearHorizontalIntent = absDx > (absDy * 1.5);
                        final bool sufficientDistance = absDx >= 80;
                        final bool reasonableSpeed = elapsedMs == null
                            ? true
                            : elapsedMs > 0
                                ? (absDx / elapsedMs) > 0.3
                                : false;

                        if (!_verticalBiasDetected && clearHorizontalIntent && sufficientDistance && reasonableSpeed) {
                          if (totalDx > 0) {
                            // Swipe right -> previous day
                            setState(() {
                              _focusedDay = _focusedDay.subtract(const Duration(days: 1));
                              _selectedDay = _focusedDay;
                            });
                          } else if (totalDx < 0) {
                            // Swipe left -> next day
                            setState(() {
                              _focusedDay = _focusedDay.add(const Duration(days: 1));
                              _selectedDay = _focusedDay;
                            });
                          }
                        }

                        // Reset tracking
                        _pointerDownPos = null;
                        _pointerLastPos = null;
                        _pointerDownAt = null;
                        _verticalBiasDetected = false;
                      },
                      behavior: HitTestBehavior.opaque,
                      child: Container(
                        constraints: BoxConstraints(
                          minHeight: MediaQuery.of(context).size.height * 0.4,
                        ),
                        child: ActivitiesList(
                          selectedDate: _selectedDay ?? _focusedDay,
                          onDragStarted: () =>
                              setState(() => _isDragActive = true),
                          onDragEnded: () =>
                              setState(() => _isDragActive = false),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Delete zone that appears during drag
              if (_isDragActive) _buildDeleteZone(),
            ],
          ),
        ),
        floatingActionButton: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            boxShadow: [
              BoxShadow(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: FloatingActionButton(
            heroTag: "add_activity",
            onPressed: () {
              _showBottomSheet(
                context,
                AddActivityBottomSheet(selectedDate: _selectedDay ?? _focusedDay),
              );
            },
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Theme.of(context).colorScheme.onPrimary,
            elevation: 0,
            child: const Icon(
              Icons.add,
              size: 28,
            ),
          ),
        ),
      ),
    );
  }
}
