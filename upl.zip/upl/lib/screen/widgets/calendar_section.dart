import 'package:flutter/material.dart';
import '../../helper/date_helper.dart';
import '../../model/activity.dart';

class CalendarSection extends StatefulWidget {
  final DateTime focusedDay;
  final DateTime? selectedDay;
  final bool isCalendarVisible;
  final List<Activity> activities;
  final Function(DateTime, DateTime) onDaySelected;
  final Function(DateTime) onPageChanged;
  final VoidCallback onPreviousDay;
  final VoidCallback onToday;
  final VoidCallback onNextDay;
  final VoidCallback onToggleCalendar;

  const CalendarSection({
    super.key,
    required this.focusedDay,
    required this.selectedDay,
    required this.isCalendarVisible,
    required this.activities,
    required this.onDaySelected,
    required this.onPageChanged,
    required this.onPreviousDay,
    required this.onToday,
    required this.onNextDay,
    required this.onToggleCalendar,
  });

  @override
  State<CalendarSection> createState() => _CalendarSectionState();
}

class _CalendarSectionState extends State<CalendarSection>
    with TickerProviderStateMixin {
  late AnimationController _expandController;
  late AnimationController _slideController;
  late Animation<double> _expandAnimation;
  late Animation<Offset> _slideAnimation;
  int _monthSwipeDirection = 1; // 1: next (left swipe), -1: previous (right swipe)

  @override
  void initState() {
    super.initState();
    
    _expandController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _expandAnimation = CurvedAnimation(
      parent: _expandController,
      curve: Curves.easeInOut,
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, -0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));
  }

  @override
  void dispose() {
    _expandController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(CalendarSection oldWidget) {
    super.didUpdateWidget(oldWidget);
    
    if (widget.isCalendarVisible != oldWidget.isCalendarVisible) {
      if (widget.isCalendarVisible) {
        _expandController.forward();
        _slideController.forward();
      } else {
        _expandController.reverse();
        _slideController.reverse();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final String formattedDate =
        '${widget.focusedDay.day} ${DateHelper.getMonthName(widget.focusedDay.month)} ${widget.focusedDay.year}';

    return Column(
      children: [
        // Enhanced Date Bar with modern design
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Theme.of(context).colorScheme.surface,
                  Theme.of(context).colorScheme.surface.withOpacity(0.95),
                ],
              ),
              borderRadius: BorderRadius.circular(24.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.08),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: widget.onToggleCalendar,
                borderRadius: BorderRadius.circular(24.0),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 24.0,
                    vertical: 20.0,
                  ),
                  child: Row(
                    children: [
                      // Calendar icon with enhanced design
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Theme.of(context).colorScheme.primary,
                              Theme.of(context).colorScheme.primary.withOpacity(0.8),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.calendar_month,
                          color: Theme.of(context).colorScheme.onPrimary,
                          size: 28,
                        ),
                      ),
                      
                      const SizedBox(width: 20),
                      
                      // Date text with improved typography
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Today\'s Date',
                              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                color: Theme.of(context).colorScheme.onSurfaceVariant,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              formattedDate,
                              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                color: Theme.of(context).colorScheme.onSurface,
                                fontWeight: FontWeight.bold,
                                letterSpacing: -0.5,
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Animated arrow icon
                      AnimatedRotation(
                        turns: widget.isCalendarVisible ? 0.5 : 0.0,
                        duration: const Duration(milliseconds: 300),
                        curve: Curves.easeInOut,
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.primaryContainer,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(
                            Icons.keyboard_arrow_down_rounded,
                            color: Theme.of(context).colorScheme.primary,
                            size: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),

        // Enhanced Navigation buttons
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
          child: Row(
            children: [
              Expanded(
                child: _buildNavigationButton(
                  context,
                  Icons.chevron_left,
                  'Previous',
                  widget.onPreviousDay,
                  Theme.of(context).colorScheme.secondary,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildNavigationButton(
                  context,
                  Icons.today,
                  'Today',
                  widget.onToday,
                  Theme.of(context).colorScheme.primary,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _buildNavigationButton(
                  context,
                  Icons.chevron_right,
                  'Next',
                  widget.onNextDay,
                  Theme.of(context).colorScheme.secondary,
                ),
              ),
            ],
          ),
        ),

        // Animated calendar expansion
        SizeTransition(
          sizeFactor: _expandAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: AnimatedOpacity(
              opacity: widget.isCalendarVisible ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 300),
              child: Container(
                margin: const EdgeInsets.only(top: 16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 30,
                      offset: const Offset(0, 15),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // Enhanced Calendar Header
                    _buildEnhancedHeader(),
                    // Enhanced Calendar Grid
                    _buildEnhancedCalendarGrid(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildNavigationButton(
    BuildContext context,
    IconData icon,
    String label,
    VoidCallback onPressed,
    Color color,
  ) {
    return Container(
      height: 48,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            color.withOpacity(0.1),
            color.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                color: color,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEnhancedHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 20.0),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3),
            Theme.of(context).colorScheme.primaryContainer.withOpacity(0.1),
          ],
        ),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Previous month button with enhanced design
          _buildMonthButton(
            Icons.chevron_left_rounded,
            () {
              setState(() {
                _monthSwipeDirection = -1;
              });
              final newFocusedDay = DateTime(
                widget.focusedDay.year,
                widget.focusedDay.month - 1,
                1,
              );
              widget.onPageChanged(newFocusedDay);
            },
            Theme.of(context).colorScheme.primary,
          ),

          // Month and Year display with enhanced styling
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Text(
              '${DateHelper.getMonthName(widget.focusedDay.month)} ${widget.focusedDay.year}',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary,
                letterSpacing: -0.5,
              ),
            ),
          ),

          // Next month button with enhanced design
          _buildMonthButton(
            Icons.chevron_right_rounded,
            () {
              setState(() {
                _monthSwipeDirection = 1;
              });
              final newFocusedDay = DateTime(
                widget.focusedDay.year,
                widget.focusedDay.month + 1,
                1,
              );
              widget.onPageChanged(newFocusedDay);
            },
            Theme.of(context).colorScheme.primary,
          ),
        ],
      ),
    );
  }

  Widget _buildMonthButton(IconData icon, VoidCallback onPressed, Color color) {
    return Container(
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: IconButton(
        icon: Icon(icon, color: color, size: 24),
        onPressed: onPressed,
        style: IconButton.styleFrom(
          backgroundColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(12),
        ),
      ),
    );
  }

  Widget _buildEnhancedCalendarGrid() {
    return GestureDetector(
      onHorizontalDragEnd: (DragEndDetails details) {
        // Detect swipe direction based on velocity
        if (details.primaryVelocity != null) {
          if (details.primaryVelocity! > 100) {
            // Swiped right - go to previous month
            setState(() {
              _monthSwipeDirection = -1;
            });
            final newFocusedDay = DateTime(
              widget.focusedDay.year,
              widget.focusedDay.month - 1,
              1,
            );
            widget.onPageChanged(newFocusedDay);
          } else if (details.primaryVelocity! < -100) {
            // Swiped left - go to next month
            setState(() {
              _monthSwipeDirection = 1;
            });
            final newFocusedDay = DateTime(
              widget.focusedDay.year,
              widget.focusedDay.month + 1,
              1,
            );
            widget.onPageChanged(newFocusedDay);
          }
        }
      },
      child: Container(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            // Enhanced weekday headers
            Row(
              children: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
                  .map(
                    (day) => Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
                        child: Text(
                          day,
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                            color: Theme.of(context).colorScheme.primary,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),

            // Enhanced calendar days grid
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              switchInCurve: Curves.easeOutCubic,
              switchOutCurve: Curves.easeInCubic,
              transitionBuilder: (child, animation) {
                // Slide new child in from swipe direction; old child slides out opposite
                final isNext = _monthSwipeDirection > 0;
                final inBegin = Offset(isNext ? 1.0 : -1.0, 0);
                final tween = Tween<Offset>(begin: inBegin, end: Offset.zero)
                    .chain(CurveTween(curve: Curves.easeInOut));
                return ClipRect(
                  child: SlideTransition(position: animation.drive(tween), child: child),
                );
              },
              child: KeyedSubtree(
                key: ValueKey<int>(widget.focusedDay.year * 12 + widget.focusedDay.month),
                child: Column(children: _buildEnhancedCalendarWeeks()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildEnhancedCalendarWeeks() {
    final year = widget.focusedDay.year;
    final month = widget.focusedDay.month;

    // First day of the month
    final firstDayOfMonth = DateTime(year, month, 1);

    // First day of the calendar grid (might be from previous month)
    final startDate = firstDayOfMonth.subtract(
      Duration(days: firstDayOfMonth.weekday % 7),
    );

    // Generate 6 weeks of dates
    final List<Widget> weeks = [];

    for (int week = 0; week < 6; week++) {
      final List<Widget> weekDays = [];

      for (int day = 0; day < 7; day++) {
        final date = startDate.add(Duration(days: week * 7 + day));
        final isCurrentMonth = date.month == month;
        final isSelected = _isSameDay(widget.selectedDay, date);
        final isToday = _isSameDay(DateTime.now(), date);

        weekDays.add(
          Expanded(
            child: _buildEnhancedDayCell(date, isCurrentMonth, isSelected, isToday),
          ),
        );
      }

      weeks.add(Row(children: weekDays));
    }

    return weeks;
  }

  Widget _buildEnhancedDayCell(
    DateTime date,
    bool isCurrentMonth,
    bool isSelected,
    bool isToday,
  ) {
    return GestureDetector(
      onTap: () {
        widget.onDaySelected(date, date);
      },
      child: Container(
        height: 56,
        margin: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: isSelected
              ? Theme.of(context).colorScheme.primary
              : isToday
              ? Theme.of(context).colorScheme.primaryContainer.withOpacity(0.3)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected
                ? Theme.of(context).colorScheme.primary
                : isToday
                ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
                : Theme.of(context).colorScheme.outline.withOpacity(0.1),
            width: isSelected || isToday ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ]
              : null,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Date number with enhanced typography
            Text(
              '${date.day}',
              style: TextStyle(
                color: isSelected
                    ? Theme.of(context).colorScheme.onPrimary
                    : isCurrentMonth
                    ? isToday
                          ? Theme.of(context).colorScheme.primary
                          : Theme.of(context).colorScheme.onSurface
                    : Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
                fontWeight: isSelected || isToday
                    ? FontWeight.bold
                    : FontWeight.w500,
                fontSize: 16,
              ),
            ),
            // Enhanced activity indicator dots
            if (_hasActivities(date)) ...[
              const SizedBox(height: 4),
              _buildEnhancedActivityDots(date, isSelected),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildEnhancedActivityDots(DateTime date, bool isSelected) {
    final activityInfo = _getActivityInfo(date);
    final List<Widget> dots = [];

    // Show starred activity dot (gold color)
    if (activityInfo['hasStarred']) {
      dots.add(
        Container(
          width: 5,
          height: 5,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: isSelected
                ? Theme.of(context).colorScheme.onPrimary
                : Colors.amber[600],
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: (isSelected
                        ? Theme.of(context).colorScheme.onPrimary
                        : Colors.amber[600]!)
                    .withOpacity(0.4),
                blurRadius: 2,
                offset: const Offset(0, 1),
              ),
            ],
          ),
        ),
      );
    }

    // Show regular activity dot (primary color)
    if (activityInfo['totalCount'] > 0) {
      dots.add(
        Container(
          width: 5,
          height: 5,
          margin: const EdgeInsets.symmetric(horizontal: 1),
          decoration: BoxDecoration(
            color: isSelected
                ? Theme.of(context).colorScheme.onPrimary
                : Theme.of(context).colorScheme.primary,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: (isSelected
                        ? Theme.of(context).colorScheme.onPrimary
                        : Theme.of(context).colorScheme.primary)
                    .withOpacity(0.4),
                blurRadius: 2,
                offset: const Offset(0, 1),
              ),
            ],
          ),
        ),
      );
    }

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: dots,
    );
  }

  /// Helper method to check if two dates are the same day
  bool _isSameDay(DateTime? a, DateTime b) {
    if (a == null) return false;
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  /// Helper method to check if a date has activities
  bool _hasActivities(DateTime date) {
    return widget.activities.any((activity) {
      final activityDate = activity.activityDatetime;
      return activityDate.year == date.year &&
          activityDate.month == date.month &&
          activityDate.day == date.day;
    });
  }

  /// Helper method to get activity count and types for a date
  Map<String, dynamic> _getActivityInfo(DateTime date) {
    final dateActivities = widget.activities.where((activity) {
      final activityDate = activity.activityDatetime;
      return activityDate.year == date.year &&
          activityDate.month == date.month &&
          activityDate.day == date.day;
    }).toList();

    final hasStarred = dateActivities.any((activity) => activity.activityStarred);
    final totalCount = dateActivities.length;

    return {
      'hasStarred': hasStarred,
      'totalCount': totalCount,
      'activities': dateActivities,
    };
  }
}
