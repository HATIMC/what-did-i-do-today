import 'package:flutter/material.dart';
import '../../service/media_service.dart';
import '../../model/activity.dart';
import '../../model/checklist.dart';

/// Expanded details section of an activity card
class ActivityExpandedDetails extends StatelessWidget {
  final Activity activity;
  final Function(int) onToggleChecklistItem;
  final Function(ChecklistItem) onShowChecklistItemDetails;
  final Function(int) onDeleteChecklistItem;

  const ActivityExpandedDetails({
    super.key,
    required this.activity,
    required this.onToggleChecklistItem,
    required this.onShowChecklistItemDetails,
    required this.onDeleteChecklistItem,
  });

  /// Builds a detail row with icon, label and value
  Widget _buildDetailRow(
    BuildContext context,
    IconData icon,
    String label,
    String value,
  ) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          icon,
          size: 16,
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
        const SizedBox(width: 8),
        Text(
          '$label: ',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w600,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ),
      ],
    );
  }

  /// Formats a Duration object to a readable string
  String _formatDuration(Duration duration) {
    final hours = duration.inHours;
    final minutes = duration.inMinutes % 60;

    if (hours > 0 && minutes > 0) {
      return '${hours}h ${minutes}m';
    } else if (hours > 0) {
      return '${hours}h';
    } else {
      return '${minutes}m';
    }
  }

  void _openActivityAttachment(dynamic media, BuildContext context) async {
    try {
      await MediaService.openMediaFile(media.mediaPath);
    } catch (e) {
      if (context.mounted) {
        // Show detailed instructions in a dialog for better readability
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('File Location: ${media.fileName}'),
            content: SingleChildScrollView(
              child: Text(
                e.toString(),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Full details header
          Row(
            children: [
              Icon(
                Icons.info_outline,
                color: Theme.of(context).colorScheme.primary,
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                'Activity Details',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Duration and other details
          if (activity.activityDuration != null &&
              activity.activityDuration!.inMinutes > 0) ...[
            _buildDetailRow(
              context,
              Icons.schedule,
              'Duration',
              _formatDuration(activity.activityDuration!),
            ),
            const SizedBox(height: 8),
          ],

          // Location details
          if (activity.location != null && activity.location!.isNotEmpty) ...[
            _buildDetailRow(
              context,
              Icons.location_on,
              'Location',
              activity.location!,
            ),
            const SizedBox(height: 8),
          ],

          // Tags
          if (activity.tags.isNotEmpty) ...[
            _buildDetailRow(
              context,
              Icons.tag,
              'Tags',
              activity.tags.map((tag) => '#$tag').join(', '),
            ),
            const SizedBox(height: 8),
          ],

          // Attachments (clickable)
          if (activity.activityMedia.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'Attachments (${activity.activityMedia.length})',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: activity.activityMedia.map((media) {
                return InkWell(
                  onTap: () => _openActivityAttachment(media, context),
                  borderRadius: BorderRadius.circular(8),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      color: Theme.of(
                        context,
                      ).colorScheme.primaryContainer.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: Theme.of(
                          context,
                        ).colorScheme.primary.withOpacity(0.3),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          MediaService.getIconForMediaType(media.mediaType),
                          size: 16,
                          color: Theme.of(context).colorScheme.primary,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          media.fileName,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(
                                color: Theme.of(context).colorScheme.primary,
                                fontWeight: FontWeight.w500,
                              ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ],

          // Checklist
          if (activity.checklist.isNotEmpty) ...[
            const SizedBox(height: 12),
            Text(
              'Checklist (${activity.checklist.where((item) => item.isChecked).length}/${activity.checklist.length})',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            ...activity.checklist.asMap().entries.map((entry) {
              final index = entry.key;
              final item = entry.value;
              return Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Checkbox - clickable to toggle state
                    InkWell(
                      onTap: () => onToggleChecklistItem(index),
                      borderRadius: BorderRadius.circular(4),
                      child: Padding(
                        padding: const EdgeInsets.all(2),
                        child: Icon(
                          item.isChecked
                              ? Icons.check_box
                              : Icons.check_box_outline_blank,
                          size: 18,
                          color: item.isChecked
                              ? Theme.of(context).colorScheme.primary
                              : Theme.of(context).colorScheme.outline,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    // Title - clickable to open readonly view
                    Expanded(
                      child: InkWell(
                        onTap: () => onShowChecklistItemDetails(item),
                        borderRadius: BorderRadius.circular(4),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                            vertical: 2,
                            horizontal: 4,
                          ),
                          child: Text(
                            item.checklistTitle,
                            style: Theme.of(context).textTheme.bodyMedium
                                ?.copyWith(
                                  decoration: item.isChecked
                                      ? TextDecoration.lineThrough
                                      : null,
                                  color: item.isChecked
                                      ? Theme.of(
                                          context,
                                        ).colorScheme.onSurfaceVariant
                                      : Theme.of(context).colorScheme.onSurface,
                                ),
                          ),
                        ),
                      ),
                    ),
                    // Delete button
                    InkWell(
                      onTap: () => onDeleteChecklistItem(index),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: BoxDecoration(
                          color: Theme.of(
                            context,
                          ).colorScheme.error.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Icon(
                          Icons.close,
                          size: 14,
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            }).toList(),
          ],
        ],
      ),
    );
  }
}
