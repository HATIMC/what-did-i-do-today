import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../service/profile_manager.dart';
import '../../service/activity_manager.dart';
import '../../model/activity.dart';
import '../../helper/greeting_animation_helper.dart';
import '../../helper/date_helper.dart';
import 'profile_avatar.dart';
import 'dart:async';

class HomeScreenAppBar extends StatefulWidget implements PreferredSizeWidget {
  final GreetingAnimationController animationController;
  final DateTime selectedDay;
  final VoidCallback onProfileTap;
  final VoidCallback onSettingsTap;
  final VoidCallback onAboutTap;
  final VoidCallback onNotificationsTap;

  const HomeScreenAppBar({
    super.key,
    required this.animationController,
    required this.selectedDay,
    required this.onProfileTap,
    required this.onSettingsTap,
    required this.onAboutTap,
    required this.onNotificationsTap,
  });

  @override
  Size get preferredSize => const Size.fromHeight(180.0);

  @override
  State<HomeScreenAppBar> createState() => _HomeScreenAppBarState();
}

class _HomeScreenAppBarState extends State<HomeScreenAppBar>
    with TickerProviderStateMixin {
  Timer? _reminderTimer;
  bool _hasReminders = false;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _startReminderTimer();
    
    // Initialize pulse animation for reminder indicator
    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));
    
    if (_hasReminders) {
      _pulseController.repeat(reverse: true);
    }
  }

  @override
  void dispose() {
    _reminderTimer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  void _startReminderTimer() {
    _reminderTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        final activityManager = Provider.of<ActivityManager>(
          context,
          listen: false,
        );
        final newHasReminders = _hasUpcomingReminders(
          activityManager.activities,
        );

        if (newHasReminders != _hasReminders) {
          setState(() {
            _hasReminders = newHasReminders;
          });
          
          if (newHasReminders) {
            _pulseController.repeat(reverse: true);
          } else {
            _pulseController.stop();
            _pulseController.reset();
          }
        }
      }
    });
  }

  // Helper method to check if there are upcoming reminders
  bool _hasUpcomingReminders(List<Activity> activities) {
    final now = DateTime.now();
    return activities.any((activity) {
      // Check if activity has notification enabled and reminder date/time set
      if (!activity.activityNotify || activity.reminderDateTime == null) {
        return false;
      }

      // Check if reminder is in the future
      return activity.reminderDateTime!.isAfter(now);
    });
  }

  @override
  Widget build(BuildContext context) {
    final String activityTitle = DateHelper.getActivityTitle(
      widget.selectedDay,
    );

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Theme.of(context).colorScheme.primaryContainer,
            Theme.of(context).colorScheme.primaryContainer.withOpacity(0.8),
            Theme.of(context).colorScheme.secondaryContainer.withOpacity(0.6),
          ],
        ),
        boxShadow: [
          BoxShadow(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          child: Column(
            children: [
              // Top Row: Profile Avatar + Greeting + Action Buttons
              Row(
                children: [
                  // Profile Avatar with enhanced design
                  _buildProfileAvatar(context),
                  
                  const SizedBox(width: 20),
                  
                  // Greeting Section with improved typography
                  Expanded(
                    child: _buildGreetingSection(context),
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Action Buttons with modern design
                  _buildActionButtons(context),
                ],
              ),
              
              const SizedBox(height: 24),
              
              // Bottom Row: Date Title with enhanced styling
              _buildDateTitle(context, activityTitle),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileAvatar(BuildContext context) {
    return Consumer<ProfileManager>(
      builder: (_, profileManager, __) {
        // Show loading indicator if profiles haven't loaded yet
        if (!profileManager.isLoaded) {
          return Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Theme.of(context).colorScheme.surface.withOpacity(0.3),
              border: Border.all(
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
                width: 2,
              ),
            ),
            child: Center(
              child: SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
            ),
          );
        }

        final imagePath = profileManager.currentProfile?.profileImage;
        return GestureDetector(
          onTap: widget.onProfileTap,
          child: Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ProfileAvatar(imagePath: imagePath, radius: 32),
          ),
        );
      },
    );
  }

  Widget _buildGreetingSection(BuildContext context) {
    return Consumer<ProfileManager>(
      builder: (context, profileManager, child) {
        if (!profileManager.isLoaded) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 120,
                height: 20,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 8),
              Container(
                width: 80,
                height: 16,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          );
        }

        final String greeting = GreetingAnimationController.getGreeting();
        String greetingText = '';
        String nameText = '';

        if (widget.animationController.animatedText.isNotEmpty) {
          if (widget.animationController.animatedText.length <= greeting.length) {
            greetingText = widget.animationController.animatedText;
          } else {
            greetingText = greeting;
            final remainingText = widget.animationController.animatedText
                .substring(greeting.length)
                .trim();
            if (remainingText.startsWith('I am ')) {
              nameText = remainingText;
            }
          }
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Greeting text
            Text(
              '$greetingText${widget.animationController.showCursor && widget.animationController.isAnimating && greetingText.length < greeting.length ? "|" : ""}',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface,
                letterSpacing: -0.2,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 4),
            // Name text
            Text(
              '$nameText${widget.animationController.showCursor && widget.animationController.isAnimating && greetingText.length >= greeting.length ? "|" : ""}',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w500,
                color: Theme.of(context).colorScheme.onSurface.withOpacity(0.8),
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        );
      },
    );
  }

  Widget _buildActionButtons(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Notifications Button with enhanced design
        _buildNotificationButton(context),
        
        const SizedBox(width: 12),
        
        // Settings Button
        _buildActionButton(
          context,
          Icons.settings_outlined,
          'Settings',
          widget.onSettingsTap,
          Theme.of(context).colorScheme.secondary,
        ),
        
        const SizedBox(width: 12),
        
        // About Button
        _buildActionButton(
          context,
          Icons.info_outline,
          'About',
          widget.onAboutTap,
          Theme.of(context).colorScheme.tertiary,
        ),
      ],
    );
  }

  Widget _buildNotificationButton(BuildContext context) {
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            color: _hasReminders
                ? Theme.of(context).colorScheme.errorContainer
                : Theme.of(context).colorScheme.surface.withOpacity(0.3),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(
              color: _hasReminders
                  ? Theme.of(context).colorScheme.error.withOpacity(0.3)
                  : Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
              width: 1,
            ),
            boxShadow: _hasReminders
                ? [
                    BoxShadow(
                      color: Theme.of(context).colorScheme.error.withOpacity(0.2),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: IconButton(
            onPressed: widget.onNotificationsTap,
            icon: Icon(
              _hasReminders
                  ? Icons.notifications_active
                  : Icons.notifications_outlined,
              size: 24,
            ),
            tooltip: 'Notifications',
            style: IconButton.styleFrom(
              backgroundColor: Colors.transparent,
              foregroundColor: _hasReminders
                  ? Theme.of(context).colorScheme.error
                  : Theme.of(context).colorScheme.onSurface,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              padding: const EdgeInsets.all(12),
            ),
          ),
        ),
        
        // Animated notification indicator
        if (_hasReminders)
          Positioned(
            right: 8,
            top: 8,
            child: ScaleTransition(
              scale: _pulseAnimation,
              child: Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.error,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Theme.of(context).colorScheme.error.withOpacity(0.4),
                      blurRadius: 4,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildActionButton(
    BuildContext context,
    IconData icon,
    String tooltip,
    VoidCallback onPressed,
    Color color,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon, size: 24),
        tooltip: tooltip,
        style: IconButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(12),
        ),
      ),
    );
  }

  Widget _buildDateTitle(BuildContext context, String activityTitle) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface.withOpacity(0.2),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.1),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Icon(
            Icons.calendar_today,
            color: Theme.of(context).colorScheme.onSurface,
            size: 20,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              activityTitle,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
                color: Theme.of(context).colorScheme.onSurface,
                letterSpacing: -0.2,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
