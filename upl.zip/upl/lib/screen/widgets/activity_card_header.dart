import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../service/activity_manager.dart';
import '../../model/activity.dart';
import '../../model/enum/mood.dart';
import '../../helper/categories.dart';

// Helper function to safely get emoji for a mood
String getMoodEmoji(ActivityMood mood) {
  switch (mood) {
    case ActivityMood.veryHappy:
      return '😄';
    case ActivityMood.happy:
      return '😊';
    case ActivityMood.neutral:
      return '😐';
    case ActivityMood.sad:
      return '😔';
    case ActivityMood.verySad:
      return '😢';
  }
}

/// Header section of an activity card containing category icon, title, and action buttons
class ActivityCardHeader extends StatelessWidget {
  final Activity activity;
  final bool isChecked;
  final DateTime selectedDate;
  final VoidCallback onCheckboxToggle;
  final VoidCallback onEditActivity;

  const ActivityCardHeader({
    super.key,
    required this.activity,
    required this.isChecked,
    required this.selectedDate,
    required this.onCheckboxToggle,
    required this.onEditActivity,
  });

  /// Determines if the bell notification icon should be shown
  bool _shouldShowBellIcon() {
    final now = DateTime.now();
    final activityDateTime = activity.activityDatetime;

    // Show bell if:
    // 1. Activity is in the future
    // 2. Activity notification is enabled
    // 3. Activity has a reminder date and time set
    return activityDateTime.isAfter(now) &&
        activity.activityNotify &&
        activity.reminderDateTime != null;
  }

  /// Determines if the activity is from a different date than the selected date
  bool _isFromDifferentDate() {
    final activityDate = activity.activityDatetime;
    return activityDate.year != selectedDate.year ||
        activityDate.month != selectedDate.month ||
        activityDate.day != selectedDate.day;
  }

  /// Formats the date difference for the indicator
  String _formatDateDifference(DateTime date) {
    final now = DateTime.now();
    final difference = date.difference(now);
    
    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Tomorrow';
    } else if (difference.inDays == -1) {
      return 'Yesterday';
    } else if (difference.inDays > 1) {
      return '${difference.inDays} days ahead';
    } else {
      return '${difference.inDays.abs()} days ago';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        // Category icon (replaces checkbox on left)
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Theme.of(
              context,
            ).colorScheme.primaryContainer.withOpacity(0.3),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            getIconForCategory(activity.activityCategory),
            size: 24,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
        const SizedBox(width: 12),
        // Title and category
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                activity.activityTitle,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  decoration: activity.activityDone
                      ? TextDecoration.lineThrough
                      : null,
                  color: activity.activityDone
                      ? Theme.of(context).colorScheme.onSurface.withOpacity(0.6)
                      : null,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 2),
              Text(
                activity.activityCategory,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
              // Show indicator for starred activities from different dates
              if (activity.activityStarred && _isFromDifferentDate()) ...[
                const SizedBox(height: 4),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.schedule_outlined,
                      size: 12,
                      color: Theme.of(context).colorScheme.secondary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _formatDateDifference(activity.activityDatetime),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.secondary,
                        fontSize: 10,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
        // Action buttons (right aligned)
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Mood emoji (indicator only, not clickable)
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.surfaceVariant.withOpacity(0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                getMoodEmoji(activity.activityMood),
                style: const TextStyle(fontSize: 20),
              ),
            ),
            // Bell icon (only if activity is in future and has notification)
            if (_shouldShowBellIcon()) ...[
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.amber.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  Icons.notifications_active,
                  size: 20,
                  color: Colors.amber.shade700,
                ),
              ),
            ],
            // Edit button (pencil icon)
            const SizedBox(width: 8),
            Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: onEditActivity,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Theme.of(
                      context,
                    ).colorScheme.secondaryContainer.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.edit,
                    size: 20,
                    color: Theme.of(context).colorScheme.onSecondaryContainer,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Star button
            Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () async {
                  final activityManager = Provider.of<ActivityManager>(
                    context,
                    listen: false,
                  );
                  await activityManager.toggleActivityStar(activity.activityId);
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: activity.activityStarred
                        ? Colors.amber.withOpacity(0.2)
                        : Theme.of(
                            context,
                          ).colorScheme.surfaceVariant.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    activity.activityStarred ? Icons.star : Icons.star_border,
                    size: 20,
                    color: activity.activityStarred
                        ? Colors.amber
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            // Checkbox
            Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(8),
              child: InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: onCheckboxToggle,
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: isChecked
                        ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                        : Theme.of(
                            context,
                          ).colorScheme.surfaceVariant.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    isChecked ? Icons.check_box : Icons.check_box_outline_blank,
                    size: 20,
                    color: isChecked
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
