import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../service/activity_manager.dart';
import '../../model/activity.dart';
import '../../model/checklist.dart';
import '../../helper/categories.dart';
import '../../features/add_activity_bottom_sheet.dart';
import 'activity_card_header.dart';
import 'activity_card_content.dart';
import 'activity_expanded_details.dart';
import 'checklist_item_details_sheet.dart';

/// A card widget that displays an individual activity with expandable details
class ActivityCard extends StatefulWidget {
  final Activity activity;
  final bool isExpanded;
  final DateTime selectedDate;
  final VoidCallback onTap;
  final Function(Activity)? onDragToDelete; // Add callback for drag deletion
  final VoidCallback? onDragStarted; // Add callback for drag start
  final VoidCallback? onDragEnded; // Add callback for drag end

  const ActivityCard({
    super.key,
    required this.activity,
    required this.isExpanded,
    required this.selectedDate,
    required this.onTap,
    this.onDragToDelete, // Add optional callback
    this.onDragStarted, // Add optional callback
    this.onDragEnded, // Add optional callback
  });

  @override
  State<ActivityCard> createState() => _ActivityCardState();
}

class _ActivityCardState extends State<ActivityCard>
    with TickerProviderStateMixin {
  late AnimationController _expansionAnimationController;
  late Animation<double> _expansionAnimation;

  @override
  void initState() {
    super.initState();
    _expansionAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _expansionAnimation = CurvedAnimation(
      parent: _expansionAnimationController,
      curve: Curves.easeInOut,
    );

    // Set initial animation state
    if (widget.isExpanded) {
      _expansionAnimationController.value = 1.0;
    }
  }

  @override
  void didUpdateWidget(ActivityCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Animate expansion/collapse when isExpanded changes
    if (widget.isExpanded != oldWidget.isExpanded) {
      if (widget.isExpanded) {
        _expansionAnimationController.forward();
      } else {
        _expansionAnimationController.reverse();
      }
    }
  }

  @override
  void dispose() {
    _expansionAnimationController.dispose();
    super.dispose();
  }

  // Store checkbox states in shared preferences and update activity
  Future<void> _saveCheckboxState(String activityId, bool isChecked) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('activity_checked_$activityId', isChecked);

    final activityManager = Provider.of<ActivityManager>(
      context,
      listen: false,
    );

    if (isChecked) {
      // If marking as completed, clear notifications and mark as done
      final updatedActivity = widget.activity.copyWith(
        activityNotify: false,
        reminderDateTime: null,
        activityDone: true,
      );
      await activityManager.updateActivity(updatedActivity);
    } else {
      // If unchecking, mark as not done
      final updatedActivity = widget.activity.copyWith(activityDone: false);
      await activityManager.updateActivity(updatedActivity);
    }
  }

  Future<bool> _getCheckboxState(String activityId) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('activity_checked_$activityId') ?? false;
  }

  /// Toggles a checklist item's completed state and updates the activity
  void _toggleChecklistItem(int checklistIndex) async {
    final activityManager = Provider.of<ActivityManager>(
      context,
      listen: false,
    );

    // Create a new checklist with the toggled item
    final updatedChecklist = List<ChecklistItem>.from(
      widget.activity.checklist,
    );
    final item = updatedChecklist[checklistIndex];
    updatedChecklist[checklistIndex] = item.copyWith(
      isChecked: !item.isChecked,
    );

    // Update the activity with the new checklist
    final updatedActivity = widget.activity.copyWith(
      checklist: updatedChecklist,
    );
    await activityManager.updateActivity(updatedActivity);
  }

  /// Shows checklist item details in a read-only bottom sheet
  void _showChecklistItemDetails(ChecklistItem item) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: false,
      enableDrag: true,
      builder: (context) => ChecklistItemDetailsSheet(item: item),
    );
  }

  /// Deletes a checklist item from the activity
  void _deleteChecklistItem(int checklistIndex) async {
    // Show confirmation dialog
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Checklist Item'),
        content: const Text(
          'Are you sure you want to delete this checklist item? This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      final activityManager = Provider.of<ActivityManager>(
        context,
        listen: false,
      );

      // Create a new checklist without the deleted item
      final updatedChecklist = List<ChecklistItem>.from(
        widget.activity.checklist,
      );
      updatedChecklist.removeAt(checklistIndex);

      // Update the activity with the new checklist
      final updatedActivity = widget.activity.copyWith(
        checklist: updatedChecklist,
      );
      await activityManager.updateActivity(updatedActivity);
    }
  }

  /// Opens the edit activity bottom sheet
  void _editActivity() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) =>
          AddActivityBottomSheet(existingActivity: widget.activity),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _getCheckboxState(widget.activity.activityId),
      builder: (context, snapshot) {
        final isChecked = snapshot.data ?? false;

        return LongPressDraggable<Activity>(
          data: widget.activity,
          dragAnchorStrategy: childDragAnchorStrategy,
          feedback: Material(
            elevation: 8,
            borderRadius: BorderRadius.circular(16.0),
            child: Container(
              width: MediaQuery.of(context).size.width - 32,
              padding: const EdgeInsets.all(16.0),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.surface,
                borderRadius: BorderRadius.circular(16.0),
                border: Border.all(
                  color: Theme.of(context).colorScheme.primary,
                  width: 2,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    getIconForCategory(widget.activity.activityCategory),
                    color: Theme.of(context).colorScheme.primary,
                    size: 24,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      widget.activity.activityTitle,
                      style: Theme.of(context).textTheme.titleMedium,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ),
            ),
          ),
          childWhenDragging: Opacity(
            opacity: 0.5,
            child: _buildActivityCard(context, isChecked),
          ),
          onDragStarted: () {
            HapticFeedback.mediumImpact();
            widget.onDragStarted?.call();
          },
          onDragEnd: (details) {
            widget.onDragEnded?.call();
          },
          child: _buildActivityCard(context, isChecked),
        );
      },
    );
  }

  Widget _buildActivityCard(BuildContext context, bool isChecked) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(16.0),
        boxShadow: [
          BoxShadow(
            color: Theme.of(
              context,
            ).shadowColor.withOpacity(widget.isExpanded ? 0.15 : 0.1),
            blurRadius: widget.isExpanded ? 12 : 8,
            offset: Offset(0, widget.isExpanded ? 3 : 2),
          ),
        ],
        border: Border.all(
          color: widget.activity.activityStarred
              ? Theme.of(context).colorScheme.primary.withOpacity(0.3)
              : widget.isExpanded
              ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
              : Colors.transparent,
          width: widget.isExpanded ? 2 : 1,
        ),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(16.0),
        child: AnimatedScale(
          duration: const Duration(milliseconds: 150),
          scale: widget.isExpanded ? 1.02 : 1.0,
          child: InkWell(
            borderRadius: BorderRadius.circular(16.0),
            onTap: widget.onTap,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header row with category icon, title, and action buttons
                  ActivityCardHeader(
                    activity: widget.activity,
                    isChecked: isChecked,
                    selectedDate: widget.selectedDate,
                    onCheckboxToggle: () async {
                      final newState = !isChecked;
                      await _saveCheckboxState(
                        widget.activity.activityId,
                        newState,
                      );
                      setState(() {});
                    },
                    onEditActivity: _editActivity,
                  ),
                  const SizedBox(height: 12),

                  // Content section
                  ActivityCardContent(
                    activity: widget.activity,
                    isExpanded: widget.isExpanded,
                  ),

                  // Expanded details section with animation
                  AnimatedSize(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                    child: widget.isExpanded
                        ? Column(
                            children: [
                              const SizedBox(height: 16),
                              FadeTransition(
                                opacity: _expansionAnimation,
                                child: SlideTransition(
                                  position: Tween<Offset>(
                                    begin: const Offset(0, -0.1),
                                    end: Offset.zero,
                                  ).animate(_expansionAnimation),
                                  child: ActivityExpandedDetails(
                                    activity: widget.activity,
                                    onToggleChecklistItem: _toggleChecklistItem,
                                    onShowChecklistItemDetails:
                                        _showChecklistItemDetails,
                                    onDeleteChecklistItem: _deleteChecklistItem,
                                  ),
                                ),
                              ),
                            ],
                          )
                        : const SizedBox.shrink(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
