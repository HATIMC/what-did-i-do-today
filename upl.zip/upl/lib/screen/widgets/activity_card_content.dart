import 'package:flutter/material.dart';
import '../../model/activity.dart';

/// Content section of an activity card containing description and footer info
class ActivityCardContent extends StatelessWidget {
  final Activity activity;
  final bool isExpanded;

  const ActivityCardContent({
    super.key,
    required this.activity,
    required this.isExpanded,
  });

  Widget _buildInfoChip(
    BuildContext context,
    IconData icon,
    String text, {
    bool isClickable = false,
    VoidCallback? onTap,
  }) {
    final chip = Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isClickable
            ? Theme.of(context).colorScheme.primaryContainer.withOpacity(0.5)
            : Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(6),
        border: isClickable
            ? Border.all(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
              )
            : null,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 12,
            color: isClickable
                ? Theme.of(context).colorScheme.primary
                : Theme.of(context).colorScheme.onSurfaceVariant,
          ),
          const SizedBox(width: 4),
          Text(
            text,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: isClickable
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.onSurfaceVariant,
              fontSize: 11,
              fontWeight: isClickable ? FontWeight.w600 : FontWeight.normal,
            ),
          ),
        ],
      ),
    );

    if (isClickable && onTap != null) {
      return InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: chip,
      );
    }

    return chip;
  }

  void _showAttachmentsBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: DraggableScrollableSheet(
          initialChildSize: 0.4,
          minChildSize: 0.3,
          maxChildSize: 0.8,
          builder: (context, scrollController) => SingleChildScrollView(
            controller: scrollController,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Handle
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: Theme.of(
                          context,
                        ).colorScheme.onSurfaceVariant.withOpacity(0.4),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  // Title
                  Text(
                    'Attachments (${activity.activityMedia.length})',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  // Attachments list - this would need to be implemented with media handling
                  Text(
                    'Attachment viewing functionality needs to be implemented',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final time = TimeOfDay.fromDateTime(activity.activityDatetime);
    final timeString = time.format(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Description (one line with ellipsis when collapsed, full when expanded)
        if (activity.activityContent.isNotEmpty)
          Text(
            activity.activityContent,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
            ),
            maxLines: isExpanded ? null : 1,
            overflow: isExpanded ? TextOverflow.visible : TextOverflow.ellipsis,
          ),
        const SizedBox(height: 8),
        // Footer row with additional info and time
        Row(
          children: [
            // Left side: tags, location, attachments
            Expanded(
              child: Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  // Location
                  if (activity.location != null &&
                      activity.location!.isNotEmpty)
                    _buildInfoChip(
                      context,
                      Icons.location_on,
                      activity.location!,
                    ),
                  // Tags
                  if (activity.tags.isNotEmpty)
                    _buildInfoChip(
                      context,
                      Icons.tag,
                      '#${activity.tags.take(2).join(' #')}${activity.tags.length > 2 ? '...' : ''}',
                    ),
                  // Checklist indicator
                  if (activity.checklist.isNotEmpty)
                    _buildInfoChip(
                      context,
                      Icons.checklist,
                      '${activity.checklist.where((item) => item.isChecked).length}/${activity.checklist.length}',
                    ),
                  // Media indicator
                  if (activity.activityMedia.isNotEmpty)
                    _buildInfoChip(
                      context,
                      Icons.attachment,
                      '${activity.activityMedia.length}',
                      isClickable: true,
                      onTap: () => _showAttachmentsBottomSheet(context),
                    ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            // Right side: time
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.surfaceVariant.withOpacity(0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                timeString,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
