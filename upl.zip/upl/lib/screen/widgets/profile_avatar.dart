import 'dart:io';
import 'package:flutter/material.dart';

/// A widget that displays a profile avatar with fallback to default avatar
class ProfileAvatar extends StatelessWidget {
  final String? imagePath;
  final double radius;
  final VoidCallback? onTap;

  const ProfileAvatar({
    super.key,
    this.imagePath,
    this.radius = 20,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget avatarContent;

    // Try to load the image, fallback to default avatar
    if (imagePath != null && imagePath!.isNotEmpty) {
      try {
        final file = File(imagePath!);
        if (file.existsSync()) {
          avatarContent = CircleAvatar(
            radius: radius,
            backgroundImage: FileImage(file),
          );
        } else {
          avatarContent = _buildDefaultAvatar(context);
        }
      } catch (e) {
        avatarContent = _buildDefaultAvatar(context);
      }
    } else {
      avatarContent = _buildDefaultAvatar(context);
    }

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: avatarContent);
    }

    return avatarContent;
  }

  Widget _buildDefaultAvatar(BuildContext context) {
    return CircleAvatar(
      radius: radius,
      backgroundColor: Theme.of(context).colorScheme.primaryContainer,
      child: Icon(
        Icons.person,
        size: radius * 0.8,
        color: Theme.of(context).colorScheme.onPrimaryContainer,
      ),
    );
  }
}
