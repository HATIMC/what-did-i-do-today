import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../service/activity_manager.dart';
import '../../service/profile_manager.dart';
import '../../model/activity.dart';
import 'activity_card.dart';

/// A widget that displays a list of activities for a given date
///
/// Features:
/// - Expandable activity cards
/// - Starred activities appear first
/// - Empty state when no activities exist
/// - Interactive checklist functionality
/// - File attachment support
class ActivitiesList extends StatefulWidget {
  final DateTime selectedDate;
  final VoidCallback? onDragStarted;
  final VoidCallback? onDragEnded;

  const ActivitiesList({
    super.key,
    required this.selectedDate,
    this.onDragStarted,
    this.onDragEnded,
  });

  @override
  State<ActivitiesList> createState() => _ActivitiesListState();
}

class _ActivitiesListState extends State<ActivitiesList>
    with TickerProviderStateMixin {
  String? _expandedActivityId; // Track which activity is expanded
  late AnimationController _dateTransitionController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _dateTransitionController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(begin: Offset.zero, end: Offset.zero)
        .animate(
          CurvedAnimation(
            parent: _dateTransitionController,
            curve: Curves.easeInOut,
          ),
        );
  }

  @override
  void didUpdateWidget(ActivitiesList oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Check if date has changed to trigger animation
    if (widget.selectedDate != oldWidget.selectedDate) {
      _animateDateTransition(oldWidget.selectedDate, widget.selectedDate);
    }
  }

  void _animateDateTransition(DateTime oldDate, DateTime newDate) {
    // Determine animation direction based on date comparison
    final isMovingForward = newDate.isAfter(oldDate);

    // Set animation direction
    _slideAnimation =
        Tween<Offset>(
          begin: isMovingForward
              ? const Offset(1.0, 0.0)
              : const Offset(-1.0, 0.0),
          end: Offset.zero,
        ).animate(
          CurvedAnimation(
            parent: _dateTransitionController,
            curve: Curves.easeInOut,
          ),
        );

    _dateTransitionController.reset();
    _dateTransitionController.forward();
  }

  @override
  void dispose() {
    _dateTransitionController.dispose();
    super.dispose();
  }

  /// Toggles activity expansion state
  void _toggleActivityExpansion(String activityId) {
    setState(() {
      if (_expandedActivityId == activityId) {
        _expandedActivityId = null; // Collapse if already expanded
      } else {
        _expandedActivityId = activityId; // Expand this activity
      }
    });
  }

  /// Sorts activities with starred ones first, then by time
  void _sortActivities(List<Activity> activities) {
    activities.sort((a, b) {
      // If one is starred and the other isn't, starred comes first
      if (a.activityStarred && !b.activityStarred) return -1;
      if (!a.activityStarred && b.activityStarred) return 1;

      // If both have same star status, sort by time (earliest first)
      return a.activityDatetime.compareTo(b.activityDatetime);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<ActivityManager>(
      builder: (context, activityManager, child) {
        if (!activityManager.isLoaded) {
          return const Center(
            child: Padding(
              padding: EdgeInsets.all(32.0),
              child: CircularProgressIndicator(),
            ),
          );
        }

        // Get activities for the selected/focused date
        final allActivities = activityManager.getActivitiesForDate(
          widget.selectedDate,
        );

        // Get all starred activities from all dates
        final allStarredActivities = activityManager.getAllStarredActivities();

        // Filter activities by current profile
        final activities = _filterActivitiesByCurrentProfile(allActivities);
        final starredActivities = _filterActivitiesByCurrentProfile(allStarredActivities);

        // Combine activities: starred activities first, then regular activities for the selected date
        final combinedActivities = <Activity>[];
        
        // Add starred activities (excluding duplicates if they're already in the selected date)
        for (final starred in starredActivities) {
          if (!activities.any((activity) => activity.activityId == starred.activityId)) {
            // Mark this starred activity as from a different date
            final starredFromDifferentDate = starred.copyWith(
              // We'll use a custom field to track this, but for now we'll just add it to the list
              // The activity card will check if the activity date matches the selected date
            );
            combinedActivities.add(starredFromDifferentDate);
          }
        }
        
        // Add regular activities for the selected date
        combinedActivities.addAll(activities);

        return SlideTransition(
          position: _slideAnimation,
          child: combinedActivities.isEmpty
              ? _buildEmptyState(context)
              : _buildActivitiesList(combinedActivities, widget.selectedDate),
        );
      },
    );
  }

  /// Filters activities by the current profile
  List<Activity> _filterActivitiesByCurrentProfile(List<Activity> activities) {
    final profileManager = Provider.of<ProfileManager>(context, listen: false);

    final currentProfile = profileManager.currentProfile;
    if (currentProfile == null) return activities;

    return activities
        .where(
          (activity) => activity.activityProfileId == currentProfile.profileId,
        )
        .toList();
  }

  /// Builds the activities list widget
  Widget _buildActivitiesList(List<Activity> activities, DateTime selectedDate) {
    // Sort activities: starred first, then by time
    _sortActivities(activities);

    return ListView.builder(
      shrinkWrap: true,
      physics: const ClampingScrollPhysics(), // Allow scrolling
      itemCount: activities.length,
      itemBuilder: (context, index) {
        final activity = activities[index];
        final isExpanded = _expandedActivityId == activity.activityId;

        return ActivityCard(
          activity: activity,
          isExpanded: isExpanded,
          selectedDate: selectedDate,
          onTap: () => _toggleActivityExpansion(activity.activityId),
          onDragStarted: widget.onDragStarted,
          onDragEnded: widget.onDragEnded,
        );
      },
    );
  }

  /// Builds the empty state when no activities exist for the selected date
  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(32.0, 120.0, 32.0, 32.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.event_available,
              size: 64,
              color: Theme.of(
                context,
              ).colorScheme.onSurfaceVariant.withOpacity(0.5),
            ),
            const SizedBox(height: 16),
            Text(
              'No activities for this day',
              style: Theme.of(context).textTheme.titleMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Starred activities from other dates will still appear here.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Tap the + button to add your first activity!',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
