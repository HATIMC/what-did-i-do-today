import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../service/activity_manager.dart';

class StatisticsCard extends StatelessWidget {
  const StatisticsCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<ActivityManager>(
      builder: (context, activityManager, child) {
        if (!activityManager.isLoaded) {
          return const SizedBox.shrink();
        }

        final stats = activityManager.getActivityStats();

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0),
          child: Card(
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16.0),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Activity Overview',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _buildStatItem(
                        context,
                        icon: Icons.event_note,
                        label: 'Total',
                        value: stats['total'].toString(),
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      _buildStatItem(
                        context,
                        icon: Icons.check_circle,
                        label: 'Completed',
                        value: stats['completed'].toString(),
                        color: Colors.green,
                      ),
                      _buildStatItem(
                        context,
                        icon: Icons.star,
                        label: 'Starred',
                        value: stats['starred'].toString(),
                        color: Colors.amber,
                      ),
                      _buildStatItem(
                        context,
                        icon: Icons.today,
                        label: 'Today',
                        value: stats['today'].toString(),
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStatItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    return Column(
      children: [
        Icon(icon, color: color, size: 28),
        const SizedBox(height: 4),
        Text(
          value,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }
}
