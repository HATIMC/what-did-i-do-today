import 'dart:convert';

enum MediaType { image, audio, document }

class ActivityMedia {
  final String mediaId;
  final String mediaPath;
  final MediaType mediaType;
  final String fileName;

  ActivityMedia({
    required this.mediaId,
    required this.mediaPath,
    required this.mediaType,
    required this.fileName,
  });

  // JSON serialization methods
  Map<String, dynamic> toJson() {
    return {
      'mediaId': mediaId,
      'mediaPath': mediaPath,
      'mediaType': mediaType.index,
      'fileName': fileName,
    };
  }

  String toRawJson() => json.encode(toJson());

  factory ActivityMedia.fromJson(Map<String, dynamic> json) {
    return ActivityMedia(
      mediaId: json['mediaId'] ?? '',
      mediaPath: json['mediaPath'] ?? '',
      mediaType: MediaType.values[json['mediaType'] ?? 0],
      fileName: json['fileName'] ?? '',
    );
  }

  factory ActivityMedia.fromRawJson(String str) =>
      ActivityMedia.fromJson(json.decode(str));

  ActivityMedia copyWith({
    String? mediaId,
    String? mediaPath,
    MediaType? mediaType,
    String? fileName,
  }) {
    return ActivityMedia(
      mediaId: mediaId ?? this.mediaId,
      mediaPath: mediaPath ?? this.mediaPath,
      mediaType: mediaType ?? this.mediaType,
      fileName: fileName ?? this.fileName,
    );
  }
}
