import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:open_file/open_file.dart';
import '../model/activity_media.dart';

class MediaService {
  static final ImagePicker _imagePicker = ImagePicker();
  static FlutterSoundRecorder? _recorder;
  static String? _recordingPath;

  /// Initialize the media service (for audio recording)
  static Future<void> initialize() async {
    _recorder = FlutterSoundRecorder();
    await _recorder!.openRecorder();
  }

  /// Dispose the media service
  static Future<void> dispose() async {
    if (_recorder != null) {
      await _recorder!.closeRecorder();
      _recorder = null;
    }
  }

  /// Take a picture using camera
  static Future<ActivityMedia?> takePicture() async {
    try {
      // Check camera permission
      if (await Permission.camera.request() != PermissionStatus.granted) {
        throw 'Camera permission denied';
      }

      final XFile? image = await _imagePicker.pickImage(
        source: ImageSource.camera,
        maxWidth: 1920,
        maxHeight: 1080,
        imageQuality: 85,
      );

      if (image != null) {
        // Get app documents directory
        final Directory appDir = await getApplicationDocumentsDirectory();
        final String fileName =
            'IMG_${DateTime.now().millisecondsSinceEpoch}.jpg';
        final String savedPath = '${appDir.path}/images/$fileName';

        // Create directory if it doesn't exist
        await Directory('${appDir.path}/images').create(recursive: true);

        // Copy file to app directory
        await File(image.path).copy(savedPath);

        return ActivityMedia(
          mediaId: DateTime.now().millisecondsSinceEpoch.toString(),
          mediaPath: savedPath,
          mediaType: MediaType.image,
          fileName: fileName,
        );
      }
    } catch (e) {
      debugPrint('Error taking picture: $e');
      rethrow;
    }
    return null;
  }

  /// Start audio recording
  static Future<void> startRecording() async {
    try {
      // Check microphone permission
      if (await Permission.microphone.request() != PermissionStatus.granted) {
        throw 'Microphone permission denied';
      }

      final Directory appDir = await getApplicationDocumentsDirectory();
      final String fileName =
          'REC_${DateTime.now().millisecondsSinceEpoch}.aac';
      _recordingPath = '${appDir.path}/audio/$fileName';

      // Create directory if it doesn't exist
      await Directory('${appDir.path}/audio').create(recursive: true);

      await _recorder!.startRecorder(toFile: _recordingPath);
    } catch (e) {
      debugPrint('Error starting recording: $e');
      rethrow;
    }
  }

  /// Stop audio recording and return ActivityMedia
  static Future<ActivityMedia?> stopRecording() async {
    try {
      await _recorder!.stopRecorder();

      if (_recordingPath != null && File(_recordingPath!).existsSync()) {
        final fileName = _recordingPath!.split('/').last;
        return ActivityMedia(
          mediaId: DateTime.now().millisecondsSinceEpoch.toString(),
          mediaPath: _recordingPath!,
          mediaType: MediaType.audio,
          fileName: fileName,
        );
      }
    } catch (e) {
      debugPrint('Error stopping recording: $e');
      rethrow;
    }
    return null;
  }

  /// Check if currently recording
  static bool get isRecording => _recorder?.isRecording ?? false;

  /// Pick a file from device storage
  static Future<ActivityMedia?> pickFile() async {
    try {
      debugPrint('📁 Starting file picker...');

      // On Android 15+, try without requesting storage permission first
      // The system will handle scoped storage automatically
      FilePickerResult? result;

      try {
        // First attempt: Use file picker without explicit permission check
        // This works with Android's scoped storage on newer versions
        result = await FilePicker.platform.pickFiles(
          allowMultiple: false,
          type: FileType.any,
          allowCompression: false, // Prevent corruption during selection
        );
      } catch (e) {
        debugPrint('📁 First attempt failed: $e');

        // Second attempt: Check and request permissions if needed
        bool hasPermission = false;

        // Try different permission strategies based on Android version
        try {
          // Check if we have modern media permissions (Android 13+)
          final photosStatus = await Permission.photos.status;
          if (photosStatus.isGranted) {
            hasPermission = true;
            debugPrint('📁 Using photos permission for file access');
          }
        } catch (e) {
          debugPrint('📁 Photos permission check failed: $e');
        }

        if (!hasPermission) {
          try {
            // Try legacy storage permission
            final storageStatus = await Permission.storage.request();
            hasPermission = storageStatus.isGranted;
            debugPrint('📁 Storage permission status: $storageStatus');
          } catch (e) {
            debugPrint('📁 Storage permission request failed: $e');
          }
        }

        if (!hasPermission) {
          try {
            // Try requesting manage external storage (requires user to go to settings)
            final manageStatus = await Permission.manageExternalStorage.status;
            if (manageStatus.isDenied) {
              debugPrint(
                '📁 MANAGE_EXTERNAL_STORAGE needed - user must enable in Settings',
              );
              throw 'For full file access, please enable "All files access" in Settings > Apps > My Tasks > Permissions';
            }
          } catch (e) {
            debugPrint('📁 Manage external storage check failed: $e');
          }
        }

        // Retry file picker
        result = await FilePicker.platform.pickFiles(
          allowMultiple: false,
          type: FileType.any,
          allowCompression: false,
        );
      }

      if (result != null && result.files.isNotEmpty) {
        final PlatformFile file = result.files.first;
        debugPrint('📁 File selected: ${file.name} (${file.size} bytes)');

        if (file.path != null) {
          // Get app documents directory
          final Directory appDir = await getApplicationDocumentsDirectory();
          final String fileName = file.name;
          final String savedPath = '${appDir.path}/documents/$fileName';

          // Create directory if it doesn't exist
          await Directory('${appDir.path}/documents').create(recursive: true);

          // Copy file to app directory
          await File(file.path!).copy(savedPath);
          debugPrint('📁 File saved to: $savedPath');

          return ActivityMedia(
            mediaId: DateTime.now().millisecondsSinceEpoch.toString(),
            mediaPath: savedPath,
            mediaType: MediaType.document,
            fileName: fileName,
          );
        } else if (file.bytes != null) {
          // Handle case where path is null but bytes are available (common on newer Android)
          final Directory appDir = await getApplicationDocumentsDirectory();
          final String fileName = file.name;
          final String savedPath = '${appDir.path}/documents/$fileName';

          // Create directory if it doesn't exist
          await Directory('${appDir.path}/documents').create(recursive: true);

          // Write bytes to file
          final savedFile = File(savedPath);
          await savedFile.writeAsBytes(file.bytes!);
          debugPrint('📁 File saved from bytes to: $savedPath');

          return ActivityMedia(
            mediaId: DateTime.now().millisecondsSinceEpoch.toString(),
            mediaPath: savedPath,
            mediaType: MediaType.document,
            fileName: fileName,
          );
        }
      } else {
        debugPrint('📁 No file selected by user');
      }
    } catch (e) {
      debugPrint('📁 Error picking file: $e');
      rethrow;
    }
    return null;
  }

  /// Get icon for media type
  static IconData getIconForMediaType(MediaType type) {
    switch (type) {
      case MediaType.image:
        return Icons.photo;
      case MediaType.audio:
        return Icons.audiotrack;
      case MediaType.document:
        return Icons.insert_drive_file;
    }
  }

  /// Get icon for file extension
  static IconData getIconForFile(String fileName) {
    final extension = fileName.split('.').last.toLowerCase();
    switch (extension) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
      case 'bmp':
        return Icons.image;
      case 'mp3':
      case 'wav':
      case 'aac':
      case 'm4a':
        return Icons.audiotrack;
      case 'pdf':
        return Icons.picture_as_pdf;
      case 'doc':
      case 'docx':
        return Icons.description;
      case 'txt':
        return Icons.text_snippet;
      case 'mp4':
      case 'mov':
      case 'avi':
        return Icons.video_file;
      default:
        return Icons.insert_drive_file;
    }
  }

  /// Delete media file
  static Future<bool> deleteMediaFile(String path) async {
    try {
      final file = File(path);
      if (file.existsSync()) {
        await file.delete();
        return true;
      }
    } catch (e) {
      debugPrint('Error deleting file: $e');
    }
    return false;
  }

  /// Open a media file with the default system app
  static Future<void> openMediaFile(String filePath) async {
    try {
      final file = File(filePath);
      if (!file.existsSync()) {
        throw 'File does not exist: $filePath';
      }

      // Get file extension to determine how to handle the file
      final extension = filePath.split('.').last.toLowerCase();
      final fileName = filePath.split('/').last;

      debugPrint('🔍 Attempting to open file: $filePath');
      debugPrint('🔍 File extension: $extension');
      debugPrint('🔍 File exists: ${file.existsSync()}');

      try {
        // Try to open the file using open_file package
        debugPrint('📂 Trying to open with OpenFile...');
        final result = await OpenFile.open(filePath);

        debugPrint('📂 OpenFile result: ${result.type}');
        debugPrint('📂 OpenFile message: ${result.message}');

        // Check the result
        switch (result.type) {
          case ResultType.done:
            debugPrint('✅ File opened successfully!');
            return; // Success!

          case ResultType.noAppToOpen:
            throw 'No app installed to open .$extension files. Please install a suitable app from Google Play Store.';

          case ResultType.permissionDenied:
            throw 'Permission denied. Please allow file access in your device settings.';

          case ResultType.fileNotFound:
            throw 'File not found. The file may have been moved or deleted.';

          case ResultType.error:
            debugPrint('❌ OpenFile error: ${result.message}');
            // Try alternative approach below
            break;
        }
      } catch (e) {
        debugPrint('❌ OpenFile failed: $e');
        // Continue to try alternative approaches
      }

      // Alternative approach: Try to copy file to public directory and open
      try {
        debugPrint(
          '📁 Trying alternative approach - copying to public directory...',
        );

        if (_isImageFile(extension)) {
          // For images, try copying to Pictures directory
          await _copyToPublicDirectory(filePath, 'Pictures', fileName);
          throw 'File saved to Pictures folder. Please open your Gallery app to view "$fileName".';
        } else {
          // For other files, try copying to Downloads directory
          await _copyToPublicDirectory(filePath, 'Download', fileName);
          throw 'File saved to Downloads folder. Please open your Downloads folder to view "$fileName".';
        }
      } catch (e) {
        debugPrint('❌ Alternative approach failed: $e');
        if (e.toString().contains('saved to')) {
          // This is our success message, re-throw it
          rethrow;
        }
      }

      // If all approaches failed, provide helpful message
      String message = _getFileOpeningMessage(extension, filePath);
      throw message;
    } catch (e) {
      debugPrint('❌ Error opening file: $e');
      rethrow;
    }
  }

  static bool _isImageFile(String extension) {
    return [
      'jpg',
      'jpeg',
      'png',
      'gif',
      'bmp',
      'webp',
    ].contains(extension.toLowerCase());
  }

  static Future<void> _copyToPublicDirectory(
    String filePath,
    String publicDir,
    String fileName,
  ) async {
    try {
      // This is a simplified approach - in a real app you'd want to use proper Android/iOS APIs
      // For now, we'll just indicate what would happen
      debugPrint('📁 Would copy $fileName to $publicDir directory');

      // Note: This requires proper platform channel implementation for production use
      // For the demo, we'll throw the success message
      throw 'File would be copied to $publicDir folder.';
    } catch (e) {
      debugPrint('❌ Failed to copy to public directory: $e');
      rethrow;
    }
  }

  static String _getFileOpeningMessage(String extension, String filePath) {
    final fileName = filePath.split('/').last;

    switch (extension.toLowerCase()) {
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
      case 'bmp':
      case 'webp':
        return 'Image file "$fileName" is saved in your app. To view it:\n\n'
            '1. Go to your device Settings > Apps > My Tasks\n'
            '2. Tap "Storage & cache"\n'
            '3. Tap "Storage"\n'
            '4. Navigate to app_flutter/images/ folder\n\n'
            'Or use a file manager app to browse to the app\'s files.';
      case 'pdf':
        return 'PDF file "$fileName" is saved in your app. To open it:\n\n'
            '1. Use a file manager app\n'
            '2. Navigate to your app\'s files\n'
            '3. Open with a PDF reader (install Adobe Reader if needed)';
      case 'mp3':
      case 'wav':
      case 'aac':
      case 'm4a':
        return 'Audio file "$fileName" is saved in your app. To play it:\n\n'
            '1. Use a file manager app\n'
            '2. Navigate to your app\'s files\n'
            '3. Open with your music player';
      case 'txt':
        return 'Text file "$fileName" is saved in your app. To read it:\n\n'
            '1. Use a file manager app\n'
            '2. Navigate to your app\'s files\n'
            '3. Open with a text editor';
      default:
        return 'File "$fileName" is saved in your app storage. To access it:\n\n'
            '1. Use a file manager app\n'
            '2. Navigate to your app\'s files\n'
            '3. Open with an appropriate app';
    }
  }
}
