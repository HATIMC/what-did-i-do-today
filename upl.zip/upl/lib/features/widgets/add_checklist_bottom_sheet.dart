import 'package:flutter/material.dart';
import '../../model/checklist.dart';
import '../../model/activity_media.dart';
import 'attachments_input.dart';

class AddChecklistBottomSheet extends StatefulWidget {
  final ChecklistItem? existingItem;

  const AddChecklistBottomSheet({super.key, this.existingItem});

  @override
  State<AddChecklistBottomSheet> createState() =>
      _AddChecklistBottomSheetState();
}

class _AddChecklistBottomSheetState extends State<AddChecklistBottomSheet> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late FocusNode _titleFocusNode;
  late FocusNode _descriptionFocusNode;
  List<ActivityMedia> _mediaItems = [];

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(
      text: widget.existingItem?.checklistTitle ?? '',
    );
    _descriptionController = TextEditingController(
      text: widget.existingItem?.checklistContent ?? '',
    );
    _titleFocusNode = FocusNode();
    _descriptionFocusNode = FocusNode();
    _mediaItems = List.from(widget.existingItem?.checklistMedia ?? []);

    // Auto-focus on title field and show keyboard
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _titleFocusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _titleFocusNode.dispose();
    _descriptionFocusNode.dispose();
    super.dispose();
  }

  void _onAttachmentsChanged(List<ActivityMedia> newAttachments) {
    setState(() {
      _mediaItems = newAttachments;
    });
  }

  void _saveChecklist() {
    if (_titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a checklist title'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    final checklistItem = ChecklistItem(
      checklistId:
          widget.existingItem?.checklistId ??
          DateTime.now().millisecondsSinceEpoch.toString(),
      checklistTitle: _titleController.text.trim(),
      checklistContent: _descriptionController.text.trim(),
      checklistMedia: _mediaItems,
      isChecked: widget.existingItem?.isChecked ?? false,
    );

    Navigator.pop(context, checklistItem);
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.7,
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            children: [
              // Drag handle
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 16.0),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),

              // Header
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        widget.existingItem != null
                            ? 'Edit Checklist Item'
                            : 'Add Checklist Item',
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                    ),
                    TextButton(
                      onPressed: _saveChecklist,
                      child: const Text('Save'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Cancel'),
                    ),
                  ],
                ),
              ),

              // Scrollable content
              Expanded(
                child: SingleChildScrollView(
                  controller: scrollController,
                  padding: EdgeInsets.only(
                    left: 16.0,
                    right: 16.0,
                    top: 16.0,
                    bottom: MediaQuery.of(context).viewInsets.bottom + 16.0,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title Input
                      TextField(
                        controller: _titleController,
                        focusNode: _titleFocusNode,
                        textInputAction: TextInputAction.next,
                        onSubmitted: (value) {
                          if (value.trim().isNotEmpty) {
                            _descriptionFocusNode.requestFocus();
                          }
                        },
                        decoration: InputDecoration(
                          labelText: 'Checklist Title*',
                          hintText: 'Enter checklist item title',
                          filled: true,
                          fillColor: Theme.of(
                            context,
                          ).colorScheme.surfaceVariant,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide(
                              color: Theme.of(context).colorScheme.primary,
                              width: 2,
                            ),
                          ),
                          prefixIcon: Icon(
                            Icons.checklist_outlined,
                            color: Theme.of(context).colorScheme.primary,
                            size: 20,
                          ),
                        ),
                        textCapitalization: TextCapitalization.sentences,
                        maxLength: 100,
                      ),
                      const SizedBox(height: 16),

                      // Description Input
                      TextField(
                        controller: _descriptionController,
                        focusNode: _descriptionFocusNode,
                        decoration: InputDecoration(
                          labelText: 'Description (Optional)',
                          hintText:
                              'Add more details about this checklist item...',
                          filled: true,
                          fillColor: Theme.of(
                            context,
                          ).colorScheme.surfaceVariant,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide(
                              color: Theme.of(context).colorScheme.primary,
                              width: 2,
                            ),
                          ),
                          prefixIcon: Icon(
                            Icons.description_outlined,
                            color: Theme.of(context).colorScheme.primary,
                            size: 20,
                          ),
                        ),
                        textCapitalization: TextCapitalization.sentences,
                        maxLines: 3,
                        maxLength: 500,
                      ),
                      const SizedBox(height: 16),

                      // Attachments Input
                      AttachmentsInput(
                        attachments: _mediaItems,
                        onAttachmentsChanged: _onAttachmentsChanged,
                      ),

                      const SizedBox(height: 24),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
