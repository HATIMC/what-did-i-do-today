import 'package:flutter/material.dart';
import '../category_selector_bottom_sheet.dart';
import '../../helper/categories.dart';
import '../../model/profile.dart';
import '../../model/enum/mood.dart';

// Helper function to safely get emoji for a mood
String getMoodEmoji(ActivityMood mood) {
  switch (mood) {
    case ActivityMood.veryHappy:
      return '😄';
    case ActivityMood.happy:
      return '😊';
    case ActivityMood.neutral:
      return '😐';
    case ActivityMood.sad:
      return '😔';
    case ActivityMood.verySad:
      return '😢';
  }
}

class ActivityFormHeader extends StatelessWidget {
  final String? title; // Add title parameter
  final bool isImportant;
  final bool isCompleted;
  final bool activityNotify;
  final bool isActivityInFuture;
  final String selectedCategory;
  final Profile? selectedProfile;
  final ActivityMood mood;
  final VoidCallback onImportantToggle;
  final VoidCallback onCompletedToggle;
  final VoidCallback onMoodChanged;
  final VoidCallback onNotificationToggle;
  final Function(String) onCategoryChanged;
  final Function(Profile?) onProfileChanged;
  final Widget? bellIcon; // Custom bell icon widget

  const ActivityFormHeader({
    super.key,
    this.title, // Add title parameter
    required this.isImportant,
    required this.isCompleted,
    required this.activityNotify,
    required this.isActivityInFuture,
    required this.selectedCategory,
    required this.selectedProfile,
    required this.mood,
    required this.onImportantToggle,
    required this.onCompletedToggle,
    required this.onMoodChanged,
    required this.onNotificationToggle,
    required this.onCategoryChanged,
    required this.onProfileChanged,
    this.bellIcon,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Text(
                title ?? 'Add New Activity', // Use the passed title or default
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            // Left spacer to balance the design
            const Spacer(),

            // Action buttons (right aligned)
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Bell notification button (only visible if activity is in future and not completed)
                if (isActivityInFuture && !isCompleted)
                  bellIcon ??
                      IconButton(
                        onPressed: onNotificationToggle,
                        icon: Icon(
                          Icons.notifications,
                          color: activityNotify
                              ? Colors.orange
                              : Theme.of(context).colorScheme.primary,
                          size: 20,
                        ),
                        tooltip: 'Set Reminder',
                        style: IconButton.styleFrom(
                          backgroundColor: activityNotify
                              ? Colors.orange.withOpacity(0.1)
                              : Theme.of(
                                  context,
                                ).colorScheme.surfaceVariant.withOpacity(0.3),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                if (isActivityInFuture && !isCompleted)
                  const SizedBox(width: 8),

                // Mood button
                IconButton(
                  onPressed: onMoodChanged,
                  icon: Text(
                    getMoodEmoji(mood),
                    style: const TextStyle(fontSize: 20),
                  ),
                  tooltip: 'Mood: ${mood.name}',
                  style: IconButton.styleFrom(
                    backgroundColor: Theme.of(
                      context,
                    ).colorScheme.surfaceVariant.withOpacity(0.3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Important toggle button
                IconButton(
                  onPressed: onImportantToggle,
                  icon: Icon(
                    isImportant ? Icons.star : Icons.star_outline,
                    color: isImportant
                        ? Colors.amber
                        : Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  tooltip: 'Mark as Important',
                  style: IconButton.styleFrom(
                    backgroundColor: isImportant
                        ? Colors.amber.withOpacity(0.1)
                        : Theme.of(
                            context,
                          ).colorScheme.surfaceVariant.withOpacity(0.3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Completed toggle button
                IconButton(
                  onPressed: onCompletedToggle,
                  icon: Icon(
                    isCompleted
                        ? Icons.check_circle
                        : Icons.check_circle_outline,
                    color: isCompleted
                        ? Colors.green
                        : Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  tooltip: 'Mark as Completed',
                  style: IconButton.styleFrom(
                    backgroundColor: isCompleted
                        ? Colors.green.withOpacity(0.1)
                        : Theme.of(
                            context,
                          ).colorScheme.surfaceVariant.withOpacity(0.3),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                // Category icon button
                IconButton(
                  onPressed: () async {
                    final selected = await showModalBottomSheet<String>(
                      context: context,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(
                          top: Radius.circular(24),
                        ),
                      ),
                      builder: (context) => CategorySelectorBottomSheet(
                        selectedCategory: selectedCategory,
                        onCategorySelected: (cat) {
                          Navigator.pop(context, cat);
                        },
                      ),
                    );
                    if (selected != null && selected != selectedCategory) {
                      onCategoryChanged(selected);
                    }
                  },
                  icon: Icon(
                    getIconForCategory(selectedCategory),
                    color: Theme.of(context).colorScheme.primary,
                    size: 20,
                  ),
                  tooltip: 'Select Category',
                  style: IconButton.styleFrom(
                    backgroundColor: Theme.of(
                      context,
                    ).colorScheme.surfaceVariant,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }
}
