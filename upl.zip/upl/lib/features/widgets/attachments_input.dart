import 'package:flutter/material.dart';
import '../../model/activity_media.dart';
import '../../service/media_service.dart';
import 'recording_dialog.dart';

class AttachmentsInput extends StatefulWidget {
  final List<ActivityMedia> attachments;
  final Function(List<ActivityMedia>) onAttachmentsChanged;

  const AttachmentsInput({
    super.key,
    required this.attachments,
    required this.onAttachmentsChanged,
  });

  @override
  State<AttachmentsInput> createState() => _AttachmentsInputState();
}

class _AttachmentsInputState extends State<AttachmentsInput> {
  void _addCameraMedia() async {
    try {
      final media = await MediaService.takePicture();
      if (media != null) {
        // Check for duplicate file names
        if (_isDuplicateAttachment(media)) {
          return;
        }

        final updatedAttachments = [...widget.attachments, media];
        widget.onAttachmentsChanged(updatedAttachments);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error capturing photo: $e'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Theme.of(context).colorScheme.error,
        ),
      );
    }
  }

  void _addAudioMedia() async {
    final media = await showDialog<ActivityMedia>(
      context: context,
      builder: (context) => const RecordingDialog(),
    );

    if (media != null) {
      // Check for duplicate file names
      if (_isDuplicateAttachment(media)) {
        return;
      }

      final updatedAttachments = [...widget.attachments, media];
      widget.onAttachmentsChanged(updatedAttachments);
    }
  }

  void _addFileMedia() async {
    try {
      final media = await MediaService.pickFile();
      if (media != null) {
        // Check for duplicate file names
        if (_isDuplicateAttachment(media)) {
          return;
        }

        final updatedAttachments = [...widget.attachments, media];
        widget.onAttachmentsChanged(updatedAttachments);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error selecting file: $e'),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Theme.of(context).colorScheme.error,
        ),
      );
    }
  }

  void _removeAttachment(int index) {
    final updatedAttachments = List<ActivityMedia>.from(widget.attachments);
    updatedAttachments.removeAt(index);
    widget.onAttachmentsChanged(updatedAttachments);
  }

  // Check if the attachment is a duplicate based on file name
  bool _isDuplicateAttachment(ActivityMedia newMedia) {
    return widget.attachments.any(
      (existingMedia) => existingMedia.fileName == newMedia.fileName,
    );
  }

  IconData _getMediaIcon(MediaType mediaType) {
    switch (mediaType) {
      case MediaType.image:
        return Icons.image_outlined;
      case MediaType.audio:
        return Icons.audio_file_outlined;
      case MediaType.document:
        return Icons.insert_drive_file_outlined;
    }
  }

  String _getMediaTypeLabel(MediaType mediaType) {
    switch (mediaType) {
      case MediaType.image:
        return 'Image';
      case MediaType.audio:
        return 'Audio';
      case MediaType.document:
        return 'File';
    }
  }

  void _openAttachment(ActivityMedia attachment) async {
    try {
      await MediaService.openMediaFile(attachment.mediaPath);
    } catch (e) {
      if (mounted) {
        // Show detailed instructions in a dialog for better readability
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('File Location: ${attachment.fileName}'),
            content: SingleChildScrollView(
              child: Text(
                e.toString(),
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Media action buttons
        Row(
          children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _addCameraMedia,
                icon: const Icon(Icons.camera_alt_outlined, size: 18),
                label: const Text('Camera'),
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.primaryContainer,
                  foregroundColor: Theme.of(
                    context,
                  ).colorScheme.onPrimaryContainer,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: _addAudioMedia,
                icon: const Icon(Icons.mic_outlined, size: 18),
                label: const Text('Audio'),
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.secondaryContainer,
                  foregroundColor: Theme.of(
                    context,
                  ).colorScheme.onSecondaryContainer,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                onPressed: _addFileMedia,
                icon: const Icon(Icons.attach_file_outlined, size: 18),
                label: const Text('File'),
                style: FilledButton.styleFrom(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.tertiaryContainer,
                  foregroundColor: Theme.of(
                    context,
                  ).colorScheme.onTertiaryContainer,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),
          ],
        ),

        // Attachments display
        if (widget.attachments.isNotEmpty) ...[
          const SizedBox(height: 16),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(
                context,
              ).colorScheme.surfaceVariant.withOpacity(0.3),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.attachment_outlined,
                      color: Theme.of(context).colorScheme.primary,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Attachments (${widget.attachments.length})',
                      style: Theme.of(context).textTheme.labelLarge?.copyWith(
                        color: Theme.of(context).colorScheme.primary,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...widget.attachments.asMap().entries.map((entry) {
                  final index = entry.key;
                  final attachment = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surface,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Theme.of(
                            context,
                          ).colorScheme.outline.withOpacity(0.2),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: Theme.of(
                                context,
                              ).colorScheme.primaryContainer,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              _getMediaIcon(attachment.mediaType),
                              color: Theme.of(
                                context,
                              ).colorScheme.onPrimaryContainer,
                              size: 16,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: InkWell(
                              onTap: () => _openAttachment(attachment),
                              borderRadius: BorderRadius.circular(8),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 4,
                                  horizontal: 4,
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      attachment.fileName,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyMedium
                                          ?.copyWith(
                                            fontWeight: FontWeight.w500,
                                            color: Theme.of(
                                              context,
                                            ).colorScheme.primary,
                                            decoration:
                                                TextDecoration.underline,
                                          ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                    Text(
                                      'Tap to open • ${_getMediaTypeLabel(attachment.mediaType)}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall
                                          ?.copyWith(
                                            color: Theme.of(
                                              context,
                                            ).colorScheme.onSurfaceVariant,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          IconButton(
                            onPressed: () => _removeAttachment(index),
                            icon: Icon(
                              Icons.close,
                              color: Theme.of(context).colorScheme.error,
                              size: 16,
                            ),
                            constraints: const BoxConstraints(
                              minWidth: 32,
                              minHeight: 32,
                            ),
                            padding: const EdgeInsets.all(4),
                            style: IconButton.styleFrom(
                              backgroundColor: Theme.of(
                                context,
                              ).colorScheme.error.withOpacity(0.1),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),
        ],
      ],
    );
  }
}
