import 'package:flutter/material.dart';
import '../../model/checklist.dart';
import 'add_checklist_bottom_sheet.dart';

/// A widget that displays and manages a checklist of items
///
/// This widget provides functionality to:
/// - Add new checklist items
/// - Edit existing items by tapping on them
/// - Toggle completion status
/// - Remove items
/// - Display attachment counts
class ChecklistInput extends StatefulWidget {
  /// The current list of checklist items
  final List<ChecklistItem> checklist;

  /// Callback function called when the checklist changes
  final Function(List<ChecklistItem>) onChecklistChanged;

  const ChecklistInput({
    super.key,
    required this.checklist,
    required this.onChecklistChanged,
  });

  @override
  State<ChecklistInput> createState() => _ChecklistInputState();
}

class _ChecklistInputState extends State<ChecklistInput> {
  // Constants for consistent styling
  static const double _borderRadius = 16.0;
  static const double _itemBorderRadius = 12.0;
  static const double _buttonVerticalPadding = 16.0;
  static const double _containerPadding = 16.0;
  static const double _itemPadding = 12.0;
  static const double _iconSize = 20.0;
  static const double _headerIconSize = 18.0;
  static const double _attachmentIconSize = 14.0;
  static const int _maxDescriptionLength = 100;
  static const double _checkboxLeftPadding = 32.0;

  /// Shows the add/edit checklist item bottom sheet
  Future<void> _showAddChecklistBottomSheet({
    ChecklistItem? existingItem,
    int? editIndex,
  }) async {
    final result = await showModalBottomSheet<ChecklistItem>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      builder: (context) => AddChecklistBottomSheet(existingItem: existingItem),
    );

    if (result != null) {
      _updateChecklist(result, editIndex);
    }
  }

  /// Updates the checklist with a new or edited item
  void _updateChecklist(ChecklistItem item, int? editIndex) {
    final updatedChecklist = List<ChecklistItem>.from(widget.checklist);
    if (editIndex != null) {
      updatedChecklist[editIndex] = item;
    } else {
      updatedChecklist.add(item);
    }
    widget.onChecklistChanged(updatedChecklist);
  }

  /// Toggles the completion status of a checklist item
  void _toggleChecklistItem(int index) {
    final item = widget.checklist[index];
    final updatedItem = item.copyWith(isChecked: !item.isChecked);
    _updateChecklist(updatedItem, index);
  }

  /// Removes a checklist item at the specified index
  void _removeChecklistItem(int index) {
    final updatedChecklist = List<ChecklistItem>.from(widget.checklist);
    updatedChecklist.removeAt(index);
    widget.onChecklistChanged(updatedChecklist);
  }

  /// Truncates description text if it exceeds the maximum length
  String _truncateDescription(String description) {
    if (description.length <= _maxDescriptionLength) return description;
    return '${description.substring(0, _maxDescriptionLength)}...';
  }

  /// Builds the attachment count indicator
  String _getAttachmentCountText(int count) {
    return '$count attachment${count != 1 ? 's' : ''}';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildAddButton(),
        if (widget.checklist.isNotEmpty) ...[
          const SizedBox(height: _containerPadding),
          _buildChecklistContainer(),
        ],
      ],
    );
  }

  /// Builds the "Add Checklist Item" button
  Widget _buildAddButton() {
    final theme = Theme.of(context);

    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: () => _showAddChecklistBottomSheet(),
        icon: Icon(
          Icons.add_task_outlined,
          color: theme.colorScheme.primary,
          size: _iconSize,
        ),
        label: const Text('Add Checklist Item'),
        style: OutlinedButton.styleFrom(
          foregroundColor: theme.colorScheme.primary,
          textStyle: theme.textTheme.bodyLarge,
          side: BorderSide(color: theme.colorScheme.outline),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(_borderRadius),
          ),
          padding: const EdgeInsets.symmetric(vertical: _buttonVerticalPadding),
        ),
      ),
    );
  }

  /// Builds the container that holds all checklist items
  Widget _buildChecklistContainer() {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(_containerPadding),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(_borderRadius),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildChecklistHeader(),
          const SizedBox(height: 12),
          ..._buildChecklistItems(),
        ],
      ),
    );
  }

  /// Builds the header showing the checklist icon and item count
  Widget _buildChecklistHeader() {
    final theme = Theme.of(context);

    return Row(
      children: [
        Icon(
          Icons.checklist_rtl_outlined,
          color: theme.colorScheme.primary,
          size: _headerIconSize,
        ),
        const SizedBox(width: 8),
        Text(
          'Checklist Items (${widget.checklist.length})',
          style: theme.textTheme.labelLarge?.copyWith(
            color: theme.colorScheme.primary,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  /// Builds the list of checklist item widgets
  List<Widget> _buildChecklistItems() {
    return widget.checklist.asMap().entries.map((entry) {
      final index = entry.key;
      final item = entry.value;
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: _ChecklistItemCard(
          item: item,
          index: index,
          onToggle: _toggleChecklistItem,
          onEdit: () => _showAddChecklistBottomSheet(
            existingItem: item,
            editIndex: index,
          ),
          onRemove: _removeChecklistItem,
          truncateDescription: _truncateDescription,
          getAttachmentCountText: _getAttachmentCountText,
        ),
      );
    }).toList();
  }
}

/// A card widget that displays an individual checklist item
class _ChecklistItemCard extends StatelessWidget {
  final ChecklistItem item;
  final int index;
  final Function(int) onToggle;
  final VoidCallback onEdit;
  final Function(int) onRemove;
  final String Function(String) truncateDescription;
  final String Function(int) getAttachmentCountText;

  const _ChecklistItemCard({
    required this.item,
    required this.index,
    required this.onToggle,
    required this.onEdit,
    required this.onRemove,
    required this.truncateDescription,
    required this.getAttachmentCountText,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: onEdit,
      borderRadius: BorderRadius.circular(
        _ChecklistInputState._itemBorderRadius,
      ),
      child: Container(
        padding: const EdgeInsets.all(_ChecklistInputState._itemPadding),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(
            _ChecklistInputState._itemBorderRadius,
          ),
          border: Border.all(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildItemHeader(context),
            if (item.checklistContent.trim().isNotEmpty) ...[
              const SizedBox(height: 6),
              _buildDescription(context),
            ],
            if (item.checklistMedia.isNotEmpty) ...[
              const SizedBox(height: 8),
              _buildAttachmentIndicator(context),
            ],
          ],
        ),
      ),
    );
  }

  /// Builds the header row with checkbox, title, and delete button
  Widget _buildItemHeader(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => onToggle(index),
          child: _buildCheckbox(context),
        ),
        const SizedBox(width: 12),
        Expanded(child: _buildTitle(context)),
        GestureDetector(
          onTap: () => onRemove(index),
          child: _buildDeleteButton(context),
        ),
      ],
    );
  }

  /// Builds the checkbox for toggling item completion
  Widget _buildCheckbox(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.all(2),
      child: Icon(
        item.isChecked ? Icons.check_box : Icons.check_box_outline_blank,
        color: item.isChecked
            ? theme.colorScheme.primary
            : theme.colorScheme.outline,
        size: _ChecklistInputState._iconSize,
      ),
    );
  }

  /// Builds the clickable title
  Widget _buildTitle(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
      child: Text(
        item.checklistTitle,
        style: theme.textTheme.bodyMedium?.copyWith(
          decoration: item.isChecked ? TextDecoration.lineThrough : null,
          color: item.isChecked
              ? theme.colorScheme.onSurfaceVariant
              : theme.colorScheme.onSurface,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  /// Builds the delete button
  Widget _buildDeleteButton(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: theme.colorScheme.error.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Icon(Icons.close, size: 16, color: theme.colorScheme.error),
    );
  }

  /// Builds the clickable description
  Widget _buildDescription(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(
        left: _ChecklistInputState._checkboxLeftPadding,
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 2, horizontal: 4),
        child: Text(
          truncateDescription(item.checklistContent),
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
            decoration: item.isChecked ? TextDecoration.lineThrough : null,
          ),
        ),
      ),
    );
  }

  /// Builds the attachment count indicator
  Widget _buildAttachmentIndicator(BuildContext context) {
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.only(
        left: _ChecklistInputState._checkboxLeftPadding,
      ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer.withValues(alpha: 0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: theme.colorScheme.primary.withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.attach_file,
              size: _ChecklistInputState._attachmentIconSize,
              color: theme.colorScheme.primary,
            ),
            const SizedBox(width: 4),
            Text(
              getAttachmentCountText(item.checklistMedia.length),
              style: theme.textTheme.bodySmall?.copyWith(
                fontSize: 12,
                color: theme.colorScheme.primary,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
