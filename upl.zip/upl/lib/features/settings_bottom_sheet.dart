import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hello_world/features/profile_selector_bottom_sheet.dart';
import 'package:hello_world/features/color_picker_bottom_sheet.dart';
import 'package:hello_world/service/activity_manager.dart';
import 'package:hello_world/service/profile_manager.dart';
import 'package:hello_world/service/theme_manager.dart'; // Import the theme manager
import 'package:hello_world/screen/widgets/profile_avatar.dart';
import 'package:hello_world/screen/home_screen.dart'; // Import HomeScreen
import 'package:provider/provider.dart'; // Import provider package
import 'package:shared_preferences/shared_preferences.dart';

class SettingsBottomSheet extends StatefulWidget {
  const SettingsBottomSheet({super.key});

  @override
  State<SettingsBottomSheet> createState() => _SettingsBottomSheetState();
}

class _SettingsBottomSheetState extends State<SettingsBottomSheet>
    with TickerProviderStateMixin {
  late TextEditingController _nameController;
  late AnimationController _darkModeAnimationController;
  late AnimationController _lockAnimationController;

  @override
  void initState() {
    super.initState();
    // Initialize controller with current user name from ThemeManager
    _nameController = TextEditingController();

    // Initialize animation controllers
    _darkModeAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _lockAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _darkModeAnimationController.dispose();
    _lockAnimationController.dispose();
    super.dispose();
  }

  /// Deletes all app data and restarts the app
  Future<void> _deleteAllData() async {
    // Show confirmation dialog
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete All Data'),
        content: const Text(
          'This will permanently delete all your activities, profiles, and settings. This action cannot be undone.\n\nAre you sure you want to continue?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Delete All Data'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      // Show second confirmation dialog
      final doubleConfirm = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: Text(
            'Final Confirmation',
            style: TextStyle(color: Theme.of(context).colorScheme.error),
          ),
          content: const Text(
            'This is your last chance. All data will be permanently lost.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('Yes, Delete Everything'),
            ),
          ],
        ),
      );

      if (doubleConfirm == true) {
        try {
          // Get all managers first
          final activityManager = Provider.of<ActivityManager>(
            context,
            listen: false,
          );
          final profileManager = Provider.of<ProfileManager>(
            context,
            listen: false,
          );
          final themeManager = Provider.of<ThemeManager>(
            context,
            listen: false,
          );

          // Clear all data from managers first
          await activityManager.clearAllActivities();

          // Clear SharedPreferences completely
          final prefs = await SharedPreferences.getInstance();
          await prefs.clear();

          // Reset all managers to defaults (this clears their in-memory state)
          themeManager.resetToDefaults();
          profileManager.resetToDefaults();

          // Check if widget is still mounted before using context
          if (mounted) {
            Navigator.pop(context); // Close settings

            // Navigate back to home to force reinitialization
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (context) => const HomeScreen()),
              (route) => false, // Remove all previous routes
            );

            // Show message after navigation
            Future.delayed(const Duration(milliseconds: 500), () {
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('All data deleted. App has been reset.'),
                    duration: Duration(seconds: 3),
                  ),
                );
              }
            });
          }
        } catch (e) {
          // Check if widget is still mounted before using context
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Error deleting data: $e'),
                backgroundColor: Theme.of(context).colorScheme.error,
              ),
            );
          }
        }
      }
    }
  }

  /// Custom animated toggle widget
  Widget _buildAnimatedToggle({
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
    required AnimationController animationController,
    required IconData activeIcon,
    required IconData inactiveIcon,
  }) {
    // Set animation controller state based on current value
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (value && animationController.value == 0) {
        animationController.forward();
      } else if (!value && animationController.value == 1) {
        animationController.reverse();
      }
    });

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
        title: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
        ),
        subtitle: Text(
          subtitle,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        trailing: GestureDetector(
          onTap: () {
            final newValue = !value;
            onChanged(newValue);
            if (newValue) {
              animationController.forward();
            } else {
              animationController.reverse();
            }
          },
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: value
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.surfaceVariant,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: value
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.outline.withOpacity(0.5),
                width: 2,
              ),
            ),
            child: AnimatedBuilder(
              animation: animationController,
              builder: (context, child) {
                return AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  transitionBuilder: (child, animation) {
                    return RotationTransition(turns: animation, child: child);
                  },
                  child: Icon(
                    value ? activeIcon : inactiveIcon,
                    key: ValueKey(value),
                    color: value
                        ? Theme.of(context).colorScheme.onPrimary
                        : Theme.of(context).colorScheme.onSurfaceVariant,
                    size: 24,
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Access the ThemeManager
    final themeManager = Provider.of<ThemeManager>(context);
    final profileManager = Provider.of<ProfileManager>(context);
    final currentProfile = profileManager.currentProfile;

    // Determine the current effective brightness of the app
    final bool isCurrentlyDarkMode =
        Theme.of(context).brightness == Brightness.dark;

    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Drag handle
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 16.0),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Text('Settings', style: Theme.of(context).textTheme.headlineSmall),
            const SizedBox(height: 16),
            // Profile Section
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Current Profile",
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 8),
                Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () {
                      showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.vertical(
                            top: Radius.circular(24),
                          ),
                        ),
                        builder: (_) => const ProfileSelectorBottomSheet(),
                      );
                    },
                    borderRadius: BorderRadius.circular(12),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceVariant,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Theme.of(context).dividerColor,
                        ),
                      ),
                      child: Row(
                        children: [
                          ProfileAvatar(
                            imagePath: currentProfile?.profileImage,
                            radius: 12,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              currentProfile?.profileName ?? "Select Profile",
                              style: Theme.of(context).textTheme.titleMedium,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          const Icon(Icons.arrow_drop_down),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // App Lock Toggle
            _buildAnimatedToggle(
              title: 'App Lock',
              subtitle: 'Require authentication when opening the app',
              value: themeManager.isLockEnabled,
              onChanged: (bool value) {
                themeManager.setLockEnabled(value);
              },
              animationController: _lockAnimationController,
              activeIcon: Icons.lock,
              inactiveIcon: Icons.lock_open,
            ),

            // Dark Mode Toggle
            _buildAnimatedToggle(
              title: 'Dark Mode',
              subtitle: 'Switch between light and dark theme',
              value: isCurrentlyDarkMode,
              onChanged: (bool value) {
                themeManager.toggleTheme(value);
              },
              animationController: _darkModeAnimationController,
              activeIcon: Icons.dark_mode,
              inactiveIcon: Icons.light_mode,
            ),

            const SizedBox(height: 16),
            const Divider(), // Add a divider for separation
            const SizedBox(height: 16),
            Text(
              'Theme Color',
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 16),
            // Dynamic Color Picker Button
            Container(
              width: double.infinity,
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.surfaceVariant.withOpacity(0.3),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
                ),
              ),
              child: Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.transparent,
                      builder: (context) => const ColorPickerBottomSheet(),
                    );
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Row(
                      children: [
                        // Current color indicator
                        Container(
                          width: 50,
                          height: 50,
                          decoration: BoxDecoration(
                            color: themeManager.seedColor,
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: Theme.of(
                                context,
                              ).colorScheme.outline.withOpacity(0.3),
                              width: 2,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: themeManager.seedColor.withOpacity(0.3),
                                blurRadius: 8,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Customize Theme Color',
                                style: Theme.of(context).textTheme.titleMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                'Choose from gradients and color wheel',
                                style: Theme.of(context).textTheme.bodySmall
                                    ?.copyWith(
                                      color: Theme.of(
                                        context,
                                      ).colorScheme.onSurfaceVariant,
                                    ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.arrow_forward_ios,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Delete All Data Section
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Theme.of(
                  context,
                ).colorScheme.errorContainer.withOpacity(0.3),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: Theme.of(context).colorScheme.error.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        Icons.warning_amber_rounded,
                        color: Theme.of(context).colorScheme.error,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Danger Zone',
                        style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: Theme.of(context).colorScheme.error,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Permanently delete all activities, profiles, and app data.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: _deleteAllData,
                      icon: const Icon(Icons.delete_forever),
                      label: const Text('Delete All Data'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Theme.of(context).colorScheme.error,
                        side: BorderSide(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),

            // Close button
            Align(
              alignment: Alignment.centerRight,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Close'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
