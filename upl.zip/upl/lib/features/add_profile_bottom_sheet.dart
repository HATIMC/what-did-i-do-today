import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hello_world/model/profile.dart';
import 'package:hello_world/service/profile_manager.dart';
import 'package:hello_world/screen/widgets/profile_avatar.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';
import 'package:path/path.dart' as path;

class AddProfileBottomSheet extends StatefulWidget {
  final Profile? existingProfile;
  final bool
  isMandatory; // New parameter to indicate if profile creation is mandatory

  const AddProfileBottomSheet({
    super.key,
    this.existingProfile,
    this.isMandatory = false, // Default to false for backward compatibility
  });

  @override
  State<AddProfileBottomSheet> createState() => _AddProfileBottomSheetState();
}

class _AddProfileBottomSheetState extends State<AddProfileBottomSheet> {
  final TextEditingController _nameController = TextEditingController();
  String? _profileImagePath;
  final ImagePicker _picker = ImagePicker();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.existingProfile != null) {
      _nameController.text = widget.existingProfile!.profileName;
      _profileImagePath = widget.existingProfile!.profileImage.isNotEmpty
          ? widget.existingProfile!.profileImage
          : null;
    }
  }

  /// Pick and crop profile image
  Future<void> _pickAndCropImage() async {
    try {
      setState(() => _isLoading = true);

      final XFile? pickedFile = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (pickedFile != null) {
        final CroppedFile? croppedFile = await ImageCropper().cropImage(
          sourcePath: pickedFile.path,
          aspectRatio: const CropAspectRatio(ratioX: 1, ratioY: 1),
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Profile Image',
              toolbarColor: Theme.of(context).colorScheme.primary,
              toolbarWidgetColor: Theme.of(context).colorScheme.onPrimary,
              initAspectRatio: CropAspectRatioPreset.square,
              lockAspectRatio: true,
              statusBarColor: Theme.of(context).colorScheme.primary,
              activeControlsWidgetColor: Theme.of(context).colorScheme.primary,
              backgroundColor: Theme.of(context).colorScheme.surface,
              // Ensure crop and cancel buttons are visible
              cropFrameColor: Theme.of(context).colorScheme.primary,
              cropGridColor: Theme.of(
                context,
              ).colorScheme.primary.withOpacity(0.3),
              dimmedLayerColor: Colors.black.withOpacity(0.8),
              // Make sure the crop button (check mark) is visible
              showCropGrid: true,
              hideBottomControls: false,
              // Fix for buttons being hidden under notification bar
              cropFrameStrokeWidth: 3,
            ),
            IOSUiSettings(
              title: 'Crop Profile Image',
              aspectRatioLockEnabled: true,
              resetAspectRatioEnabled: false,
              rotateClockwiseButtonHidden: true,
              hidesNavigationBar: false,
              minimumAspectRatio: 1.0,
            ),
            WebUiSettings(
              context: context,
              presentStyle: WebPresentStyle.dialog,
              size: const CropperSize(width: 520, height: 520),
            ),
          ],
        );

        if (croppedFile != null) {
          // Save the image to app directory
          final String savedPath = await _saveImageToAppDirectory(
            croppedFile.path,
          );
          setState(() {
            _profileImagePath = savedPath;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error picking image: $e')));
      }
    } finally {
      setState(() => _isLoading = false);
    }
  }

  /// Save image to app documents directory
  Future<String> _saveImageToAppDirectory(String imagePath) async {
    final Directory appDir = await getApplicationDocumentsDirectory();
    final String fileName = '${const Uuid().v4()}.jpg';
    final String newPath = path.join(appDir.path, 'profile_images', fileName);

    // Create directory if it doesn't exist
    await Directory(path.dirname(newPath)).create(recursive: true);

    // Copy file to new location
    final File originalFile = File(imagePath);
    final File newFile = await originalFile.copy(newPath);

    return newFile.path;
  }

  /// Remove current profile image
  void _removeImage() {
    setState(() {
      _profileImagePath = null;
    });
  }

  void _saveProfile(BuildContext context) {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Please enter a profile name")),
      );
      return;
    }

    final profileManager = Provider.of<ProfileManager>(context, listen: false);

    // Check for duplicate names
    final isDuplicate = profileManager.isProfileNameExists(
      name,
      excludeProfileId: widget.existingProfile?.profileId,
    );

    if (isDuplicate) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("A profile with this name already exists"),
        ),
      );
      return;
    }

    if (widget.existingProfile != null) {
      final profileId = widget.existingProfile!.profileId;

      profileManager.updateProfileName(profileId, name);
      profileManager.updateProfileImage(profileId, _profileImagePath ?? '');

      // Don't change current profile when editing a different profile
      // The update methods already call notifyListeners() which will trigger UI updates
    } else {
      final newProfile = Profile(
        profileId: const Uuid().v4(),
        profileName: name,
        profileImage: _profileImagePath ?? '',
      );
      profileManager.addProfile(newProfile);
      profileManager.setCurrentProfile(newProfile.profileId);
    }

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    Widget content = Padding(
      padding: MediaQuery.of(
        context,
      ).viewInsets, // 👈 this fixes keyboard overlap
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize:
                MainAxisSize.min, // 👈 allows sheet to resize properly
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              /// Title
              Center(
                child: Text(
                  widget.existingProfile != null
                      ? 'Edit Profile'
                      : 'Create New Profile',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    color: colorScheme.primary,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),

              // Show mandatory message if this is required
              if (widget.isMandatory) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: colorScheme.primaryContainer,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        Icons.info_outline,
                        color: colorScheme.onPrimaryContainer,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Profile creation is required to continue',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onPrimaryContainer,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],

              const SizedBox(height: 24),

              /// Profile Image Section
              Center(
                child: Stack(
                  children: [
                    ProfileAvatar(imagePath: _profileImagePath, radius: 50),
                    if (_isLoading)
                      Container(
                        width: 100,
                        height: 100,
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.5),
                          shape: BoxShape.circle,
                        ),
                        child: const Center(
                          child: CircularProgressIndicator(color: Colors.white),
                        ),
                      ),
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        decoration: BoxDecoration(
                          color: colorScheme.primary,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: colorScheme.surface,
                            width: 2,
                          ),
                        ),
                        child: IconButton(
                          onPressed: _isLoading ? null : _pickAndCropImage,
                          icon: Icon(
                            Icons.camera_alt,
                            color: colorScheme.onPrimary,
                            size: 20,
                          ),
                          iconSize: 20,
                          constraints: const BoxConstraints(
                            minWidth: 36,
                            minHeight: 36,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // Remove image button (if image exists)
              if (_profileImagePath != null) ...[
                Center(
                  child: TextButton.icon(
                    onPressed: _removeImage,
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Remove Image'),
                    style: TextButton.styleFrom(
                      foregroundColor: colorScheme.error,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
              ],

              const SizedBox(height: 16),

              /// Profile Name Input
              TextField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Profile Name',
                  border: OutlineInputBorder(),
                  hintText: 'Enter a unique profile name',
                ),
              ),
              const SizedBox(height: 32),

              /// Save Button
              FilledButton.icon(
                onPressed: _isLoading ? null : () => _saveProfile(context),
                icon: _isLoading
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.save),
                label: Text(_isLoading ? "Saving..." : "Save Profile"),
              ),
            ],
          ),
        ),
      ),
    );

    // If mandatory, wrap with PopScope to prevent dismissal
    if (widget.isMandatory) {
      return PopScope(
        canPop: false, // Prevent back button dismissal when mandatory
        child: content,
      );
    }

    return content;
  }
}
