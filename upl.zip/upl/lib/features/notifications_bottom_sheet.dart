import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../service/activity_manager.dart';
import '../model/activity.dart';
import '../helper/date_helper.dart';

class NotificationsBottomSheet extends StatefulWidget {
  const NotificationsBottomSheet({super.key});

  @override
  State<NotificationsBottomSheet> createState() =>
      _NotificationsBottomSheetState();
}

class _NotificationsBottomSheetState extends State<NotificationsBottomSheet> {
  Timer? _updateTimer;
  List<Activity> _upcomingReminders = [];

  @override
  void initState() {
    super.initState();
    _updateUpcomingReminders();
    _startUpdateTimer();
  }

  @override
  void dispose() {
    _updateTimer?.cancel();
    super.dispose();
  }

  void _startUpdateTimer() {
    _updateTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (mounted) {
        _updateUpcomingReminders();
      }
    });
  }

  void _updateUpcomingReminders() {
    final activityManager = Provider.of<ActivityManager>(
      context,
      listen: false,
    );

    final now = DateTime.now();
    final newUpcomingReminders = activityManager.activities
        .where(
          (activity) =>
              activity.activityNotify &&
              activity.reminderDateTime != null &&
              activity.reminderDateTime!.isAfter(now),
        )
        .toList();

    // Sort by reminder time (earliest first)
    newUpcomingReminders.sort((a, b) {
      final aReminder = a.reminderDateTime!;
      final bReminder = b.reminderDateTime!;
      return aReminder.compareTo(bReminder);
    });

    if (!_listEquals(_upcomingReminders, newUpcomingReminders)) {
      setState(() {
        _upcomingReminders = newUpcomingReminders;
      });
    }
  }

  bool _listEquals(List<Activity> list1, List<Activity> list2) {
    if (list1.length != list2.length) return false;
    for (int i = 0; i < list1.length; i++) {
      if (list1[i].activityId != list2[i].activityId) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
        top: 20,
        left: 20,
        right: 20,
        bottom: MediaQuery.of(context).viewInsets.bottom + 20,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with close button
          Row(
            children: [
              Icon(
                Icons.notifications,
                size: 28,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  'Upcoming Reminders',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: Icon(
                  Icons.close,
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
                style: IconButton.styleFrom(
                  backgroundColor: Theme.of(
                    context,
                  ).colorScheme.surfaceVariant.withOpacity(0.3),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),

          // Content based on whether there are reminders
          if (_upcomingReminders.isEmpty)
            _buildEmptyState()
          else
            _buildRemindersList(),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.notifications_off_outlined,
            size: 64,
            color: Theme.of(
              context,
            ).colorScheme.onSurfaceVariant.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'No upcoming reminders',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Activities with reminders will appear here',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(
                context,
              ).colorScheme.onSurfaceVariant.withOpacity(0.7),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildRemindersList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${_upcomingReminders.length} upcoming reminder${_upcomingReminders.length == 1 ? '' : 's'}',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 12),
        ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.5,
          ),
          child: ListView.builder(
            shrinkWrap: true,
            itemCount: _upcomingReminders.length,
            itemBuilder: (context, index) {
              final activity = _upcomingReminders[index];
              return _buildReminderCard(activity);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildReminderCard(Activity activity) {
    final reminderTime = activity.reminderDateTime!;
    final now = DateTime.now();
    final timeUntilReminder = reminderTime.difference(now);

    String timeUntilText;
    if (timeUntilReminder.inDays > 0) {
      timeUntilText =
          'in ${timeUntilReminder.inDays} day${timeUntilReminder.inDays == 1 ? '' : 's'}';
    } else if (timeUntilReminder.inHours > 0) {
      timeUntilText =
          'in ${timeUntilReminder.inHours} hour${timeUntilReminder.inHours == 1 ? '' : 's'}';
    } else if (timeUntilReminder.inMinutes > 0) {
      timeUntilText =
          'in ${timeUntilReminder.inMinutes} minute${timeUntilReminder.inMinutes == 1 ? '' : 's'}';
    } else {
      timeUntilText =
          'in ${timeUntilReminder.inSeconds} second${timeUntilReminder.inSeconds == 1 ? '' : 's'}';
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Theme.of(context).colorScheme.outline.withOpacity(0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.primary,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  activity.activityTitle,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.only(left: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.schedule,
                      size: 16,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      DateHelper.formatTime(reminderTime),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context).colorScheme.onSurface,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      '($timeUntilText)',
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      Icons.event,
                      size: 16,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      DateHelper.formatDate(reminderTime),
                      style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context).colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
