import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'widgets/activity_form_header.dart';
import 'widgets/activity_text_field.dart';
import 'widgets/activity_details_section.dart';
import 'widgets/activity_save_button.dart';
import 'models/activity_form_models.dart';
import '../helper/categories.dart';
import '../helper/activity_datetime_helper.dart';
import '../helper/activity_reminder_helper.dart';
import '../helper/activity_creation_helper.dart';
import '../helper/activity_form_ui_helper.dart';
import '../model/checklist.dart';
import '../model/activity_media.dart';
import '../model/profile.dart';
import '../model/activity.dart';
import '../model/enum/mood.dart';
import '../service/profile_manager.dart';

class AddActivityBottomSheet extends StatefulWidget {
  final Activity? existingActivity;
  final DateTime? selectedDate; // Add selectedDate parameter

  const AddActivityBottomSheet({
    super.key,
    this.existingActivity,
    this.selectedDate, // Add selectedDate parameter
  });

  @override
  State<AddActivityBottomSheet> createState() => _AddActivityBottomSheetState();
}

class _AddActivityBottomSheetState extends State<AddActivityBottomSheet>
    with TickerProviderStateMixin {
  bool _showDateTimeInput = false;
  DateTime? _selectedDate;
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _locationController;
  late TextEditingController _tagsController;
  late FocusNode _titleFocusNode;
  late FocusNode _descriptionFocusNode;
  TimeOfDay? _selectedTime;
  bool _isImportant = false;
  bool _isCompleted = false;
  bool _activityNotify = false;
  TimeOfDay? _reminderTime;
  DateTime? _reminderDate;
  String _selectedCategory = getAllActivityCategories().first;
  int _durationHours = 0;
  int _durationMinutes = 0;
  List<String> _tags = [];
  List<ChecklistItem> _checklist = [];
  List<ActivityMedia> _attachments = [];
  Profile? _selectedProfile;
  ActivityMood _mood = ActivityMood.happy;

  // Timer and animation for bell icon
  Timer? _timeCheckTimer;
  late AnimationController _bellAnimationController;

  @override
  void initState() {
    super.initState();

    // Initialize controllers with existing data if editing
    final existing = widget.existingActivity;
    _titleController = TextEditingController(
      text: existing?.activityTitle ?? '',
    );
    _descriptionController = TextEditingController(
      text: existing?.activityContent ?? '',
    );
    _locationController = TextEditingController(text: existing?.location ?? '');
    _tagsController = TextEditingController();
    _titleFocusNode = FocusNode();
    _descriptionFocusNode = FocusNode();

    // Set initial values from existing activity or defaults
    _selectedTime = existing?.activityDatetime != null
        ? TimeOfDay.fromDateTime(existing!.activityDatetime)
        : TimeOfDay.now();

    // Use selectedDate if provided, otherwise use existing activity date or current date
    if (existing?.activityDatetime != null) {
      _selectedDate = existing!.activityDatetime;
    } else if (widget.selectedDate != null) {
      // Set to selected date with current time
      _selectedDate = DateTime(
        widget.selectedDate!.year,
        widget.selectedDate!.month,
        widget.selectedDate!.day,
        DateTime.now().hour,
        DateTime.now().minute,
      );
    } else {
      _selectedDate = DateTime.now();
    }

    _isImportant = existing?.activityStarred ?? false;
    _isCompleted = existing?.activityDone ?? false;
    _activityNotify = existing?.activityNotify ?? false;
    _selectedCategory =
        existing?.activityCategory ?? getAllActivityCategories().first;
    _mood = existing?.activityMood ?? ActivityMood.happy;

    // Parse duration from existing activity
    if (existing?.activityDuration != null) {
      final totalMinutes = existing!.activityDuration!.inMinutes;
      _durationHours = totalMinutes ~/ 60;
      _durationMinutes = totalMinutes % 60;
    } else {
      _durationHours = 0;
      _durationMinutes = 0;
    }

    // Copy existing data
    _tags = List.from(existing?.tags ?? []);
    _checklist = List.from(existing?.checklist ?? []);
    _attachments = List.from(existing?.activityMedia ?? []);

    // Set reminder data if exists
    _reminderTime = existing?.reminderDateTime != null
        ? TimeOfDay.fromDateTime(existing!.reminderDateTime!)
        : null;
    _reminderDate = existing?.reminderDateTime;

    // Show details section if editing (since it likely has more data)
    _showDateTimeInput = existing != null;

    // Initialize bell animation controller
    _bellAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    // Start timer to check future date/time every second
    _timeCheckTimer = ActivityReminderHelper.createDateTimeCheckTimer(
      onCheck: _checkActivityDateTime,
    );

    // Set the current profile as default or existing profile
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final profileManager = Provider.of<ProfileManager>(
        context,
        listen: false,
      );
      setState(() {
        // Use existing profile ID to find the profile, or default to current
        if (existing?.activityProfileId != null) {
          final foundProfile = profileManager.profiles
              .where(
                (profile) => profile.profileId == existing!.activityProfileId,
              )
              .firstOrNull;
          _selectedProfile = foundProfile ?? profileManager.currentProfile;
        } else {
          _selectedProfile = profileManager.currentProfile;
        }
      });

      // Auto-focus on title field and show keyboard
      _titleFocusNode.requestFocus();
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _locationController.dispose();
    _tagsController.dispose();
    _titleFocusNode.dispose();
    _descriptionFocusNode.dispose();
    _timeCheckTimer?.cancel();
    _bellAnimationController.dispose();
    super.dispose();
  }

  // Check if activity date/time is in the future
  void _checkActivityDateTime() {
    if (!mounted) return;

    final validation = ActivityDateTimeHelper.validateActivityDateTime(
      selectedDate: _selectedDate,
      selectedTime: _selectedTime,
      reminderDate: _reminderDate,
      reminderTime: _reminderTime,
      activityNotify: _activityNotify,
    );

    if (validation.shouldResetNotification || validation.shouldResetReminder) {
      setState(() {
        if (validation.shouldResetNotification) {
          _activityNotify = false;
        }
        if (validation.shouldResetReminder) {
          _reminderDate = null;
          _reminderTime = null;
        }
      });
    }
  }

  // Check if activity date/time is in the future
  bool _isActivityInFuture() {
    return ActivityDateTimeHelper.isActivityInFuture(
      _selectedDate,
      _selectedTime,
    );
  }

  // Handle reminder bell toggle
  Future<void> _handleReminderToggle() async {
    // Animate bell
    await ActivityReminderHelper.animateBell(_bellAnimationController);

    final result = await ActivityReminderHelper.handleReminderToggle(
      context: context,
      currentlyActive: _activityNotify,
      currentReminderDate: _reminderDate,
      currentReminderTime: _reminderTime,
      activityDate: _selectedDate,
      activityTime: _selectedTime,
      selectedDate: _selectedDate,
      selectedTime: _selectedTime,
    );

    setState(() {
      _activityNotify = result.shouldActivate;
      _reminderDate = result.reminderDate;
      _reminderTime = result.reminderTime;
    });
  }

  ActivityFormData get _formData => ActivityFormData(
    title: _titleController.text,
    description: _descriptionController.text,
    location: _locationController.text,
    category: _selectedCategory,
    date: _selectedDate,
    time: _selectedTime,
    durationHours: _durationHours,
    durationMinutes: _durationMinutes,
    tags: _tags,
    isImportant: _isImportant,
    isCompleted: _isCompleted,
    activityNotify: _activityNotify,
    reminderDate: _reminderDate,
    reminderTime: _reminderTime,
    checklist: _checklist,
    attachments: _attachments,
    selectedProfile: _selectedProfile,
    mood: _mood,
  );

  void _saveActivity() async {
    final success = await ActivityCreationHelper.handleSaveActivity(
      context: context,
      formData: _formData,
      existingActivityId: widget.existingActivity?.activityId,
    );

    if (success) {
      Navigator.pop(context);
    }
  }

  void _onTagAdded(String tag) {
    setState(() {
      _tags.add(tag);
      _tagsController.clear();
    });
  }

  void _onTagRemoved(String tag) {
    setState(() {
      _tags.remove(tag);
    });
  }

  void _onChecklistChanged(List<ChecklistItem> checklist) {
    setState(() {
      _checklist = checklist;
    });
  }

  void _onAttachmentsChanged(List<ActivityMedia> attachments) {
    setState(() {
      _attachments = attachments;
    });
  }

  void _onProfileChanged(Profile? profile) {
    setState(() {
      _selectedProfile = profile;
    });
  }

  void _onMoodChanged() {
    setState(() {
      _mood = _mood.next;
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: ActivityFormUIHelper.getInitialChildSize(
        _showDateTimeInput,
      ),
      minChildSize: 0.5,
      maxChildSize: 0.95,
      expand: false,
      snap: true,
      snapSizes: ActivityFormUIHelper.getSnapSizes(_showDateTimeInput),
      builder: (context, scrollController) {
        return Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Stack(
            children: [
              Scaffold(
                backgroundColor: Colors.transparent,
                body: SingleChildScrollView(
                  controller: scrollController,
                  child: Padding(
                    padding: EdgeInsets.only(
                      left: 16.0,
                      right: 16.0,
                      top: 16.0,
                      // Dynamic bottom padding: extra space when keyboard is visible
                      // to prevent content from being hidden behind floating button
                      bottom: MediaQuery.of(context).viewInsets.bottom > 0
                          ? MediaQuery.of(context).viewInsets.bottom + 100.0
                          : 100.0,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildDragHandle(context),
                        ActivityFormHeader(
                          title: widget.existingActivity != null
                              ? "Edit Activity"
                              : "Add New Activity",
                          isImportant: _isImportant,
                          isCompleted: _isCompleted,
                          activityNotify: _activityNotify,
                          isActivityInFuture: _isActivityInFuture(),
                          selectedCategory: _selectedCategory,
                          selectedProfile: _selectedProfile,
                          mood: _mood,
                          onImportantToggle: () =>
                              setState(() => _isImportant = !_isImportant),
                          onCompletedToggle: () {
                            setState(() {
                              _isCompleted = !_isCompleted;
                              // If marking as completed, clear notifications
                              if (_isCompleted) {
                                _activityNotify = false;
                                _reminderDate = null;
                                _reminderTime = null;
                              }
                            });
                          },
                          onMoodChanged: _onMoodChanged,
                          onNotificationToggle: _handleReminderToggle,
                          onCategoryChanged: (category) =>
                              setState(() => _selectedCategory = category),
                          onProfileChanged: _onProfileChanged,
                          bellIcon: ActivityFormUIHelper.buildAnimatedBellIcon(
                            animationController: _bellAnimationController,
                            onPressed: _handleReminderToggle,
                            isActive: _activityNotify,
                            context: context,
                          ),
                        ),
                        const SizedBox(height: 24),
                        ActivityTextField(
                          controller: _titleController,
                          focusNode: _titleFocusNode,
                          labelText: 'Activity Title*',
                          hintText: 'What did you do?',
                          prefixIcon: Icons.title_outlined,
                          maxLength: 100,
                          textInputAction: TextInputAction.next,
                          onChanged: () => setState(() {}),
                          onSubmitted: (value) {
                            if (value.trim().isNotEmpty) {
                              _descriptionFocusNode.requestFocus();
                            }
                          },
                        ),
                        const SizedBox(height: 16),
                        ActivityTextField(
                          controller: _descriptionController,
                          focusNode: _descriptionFocusNode,
                          labelText: 'Description (Optional)',
                          hintText: 'Add more details about the activity...',
                          prefixIcon: Icons.description_outlined,
                          maxLength: 500,
                          maxLines: 3,
                        ),
                        const SizedBox(height: 16),
                        _buildExpandableDetailsButton(),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              ),
              ActivitySaveButton(
                isValid: _formData.isValid,
                onSave: _saveActivity,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDragHandle(BuildContext context) {
    return ActivityFormUIHelper.buildDragHandle(context);
  }

  Widget _buildExpandableDetailsButton() {
    return ActivityFormUIHelper.buildAnimatedSwitcher(
      showDetails: _showDateTimeInput,
      collapsedWidget: ActivityFormUIHelper.buildExpandableDetailsButton(
        context: context,
        onPressed: () {
          setState(() {
            _showDateTimeInput = true;
          });
          WidgetsBinding.instance.addPostFrameCallback((_) {
            setState(() {});
          });
        },
      ),
      expandedWidget: ActivityDetailsSection(
        selectedDate: _selectedDate,
        selectedTime: _selectedTime,
        locationController: _locationController,
        durationHours: _durationHours,
        durationMinutes: _durationMinutes,
        tagsController: _tagsController,
        tags: _tags,
        checklist: _checklist,
        attachments: _attachments,
        onDateChanged: (date) => setState(() => _selectedDate = date),
        onTimeChanged: (time) => setState(() => _selectedTime = time),
        onDurationChanged: (hours, minutes) => setState(() {
          _durationHours = hours;
          _durationMinutes = minutes;
        }),
        onTagAdded: _onTagAdded,
        onTagRemoved: _onTagRemoved,
        onChecklistChanged: _onChecklistChanged,
        onAttachmentsChanged: _onAttachmentsChanged,
      ),
    );
  }
}
